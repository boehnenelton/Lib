#!/bin/bash
#===============================================================================
# Library:     lib_bejson_validator.sh
# Jurisdiction: ["BASH", "CORE_COMMAND"]
# Status:      OFFICIAL — Core-Command/Lib (v1.1)
# Author:      Elton Boehnen
# Version:     1.1 (OFFICIAL)
# Date:        2026-04-23
# Description: BEJSON validator — schema validation for 104, 104a, 104db.
MFDB validation functions are in lib_mfdb_validator.sh (decoupled).
Author:      Elton Boehnen
Version:     3.1.0 (OFFICIAL)
Date:        2026-04-16
Compat:      Bash 4.0+, Termux/Android
Requires:    jq >= 1.6 (semver-validated)
Changelog v3.1.0:
[FIX] jq semver validation: requires >= 1.6, prevents silent data corruption.
[FIX] MFDB decoupled: validation engine moved to lib_mfdb_validator.sh.
[FIX] Official status: updated to meet Core-Command/Lib standards.
Error code ranges:
1–15   → lib_bejson_validator
# Description: BEJSON validator — schema validation for 104, 104a, 104db.
#              MFDB validation functions are in lib_mfdb_validator.sh (decoupled).
#
# Changelog v3.1.0:
#   [FIX] jq semver validation: requires >= 1.6, prevents silent data corruption.
#   [FIX] MFDB decoupled: validation engine moved to lib_mfdb_validator.sh.
#   [FIX] Official status: updated to meet Core-Command/Lib standards.
#
# Error code ranges:
#   1–15   → lib_bejson_validator

#-------------------------------------------------------------------------------
# SAFETY & ERROR HANDLING
#-------------------------------------------------------------------------------

set -o pipefail
set -o nounset

# Error codes
[[ -v E_INVALID_JSON ]] || readonly E_INVALID_JSON=1
[[ -v E_MISSING_MANDATORY_KEY ]] || readonly E_MISSING_MANDATORY_KEY=2
[[ -v E_INVALID_FORMAT ]] || readonly E_INVALID_FORMAT=3
[[ -v E_INVALID_VERSION ]] || readonly E_INVALID_VERSION=4
[[ -v E_INVALID_RECORDS_TYPE ]] || readonly E_INVALID_RECORDS_TYPE=5
[[ -v E_INVALID_FIELDS ]] || readonly E_INVALID_FIELDS=6
[[ -v E_INVALID_VALUES ]] || readonly E_INVALID_VALUES=7
[[ -v E_TYPE_MISMATCH ]] || readonly E_TYPE_MISMATCH=8
[[ -v E_RECORD_LENGTH_MISMATCH ]] || readonly E_RECORD_LENGTH_MISMATCH=9
[[ -v E_RESERVED_KEY_COLLISION ]] || readonly E_RESERVED_KEY_COLLISION=10
[[ -v E_INVALID_RECORD_TYPE_PARENT ]] || readonly E_INVALID_RECORD_TYPE_PARENT=11
[[ -v E_NULL_VIOLATION ]] || readonly E_NULL_VIOLATION=12
[[ -v E_FILE_NOT_FOUND ]] || readonly E_FILE_NOT_FOUND=13
[[ -v E_PERMISSION_DENIED ]] || readonly E_PERMISSION_DENIED=14
[[ -v E_ATOMIC_WRITE_FAILED ]] || readonly E_ATOMIC_WRITE_FAILED=15

# Global validation state
__BEJSON_VALIDATION_ERRORS=()
__BEJSON_VALIDATION_WARNINGS=()
__BEJSON_CURRENT_FILE=""

#-------------------------------------------------------------------------------
# UTILITY FUNCTIONS
#-------------------------------------------------------------------------------

# Check if jq is available with semantic version validation
bejson_validator_check_dependencies() {
    local MIN_JQ_VERSION="1.6"

    if ! command -v jq &>/dev/null; then
        echo "ERROR: 'jq' is required but not installed." >&2
        return 1
    fi

    local jq_version
    jq_version=$(jq --version 2>&1 | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)

    if [[ -z "$jq_version" ]]; then
        echo "ERROR: Could not determine jq version." >&2
        return 1
    fi

    local required_major required_minor current_major current_minor
    required_major=$(echo "$MIN_JQ_VERSION" | cut -d. -f1)
    required_minor=$(echo "$MIN_JQ_VERSION" | cut -d. -f2)
    current_major=$(echo "$jq_version" | cut -d. -f1)
    current_minor=$(echo "$jq_version" | cut -d. -f2)

    if [[ "$current_major" -lt "$required_major" ]] || \
       { [[ "$current_major" -eq "$required_major" ]] && [[ "$current_minor" -lt "$required_minor" ]]; }; then
        echo "ERROR: jq version $jq_version is too old. MFDB requires jq >= ${MIN_JQ_VERSION}." >&2
        return 1
    fi

    return 0
}

# Reset validation state
bejson_validator_reset_state() {
    __BEJSON_VALIDATION_ERRORS=()
    __BEJSON_VALIDATION_WARNINGS=()
    __BEJSON_CURRENT_FILE=""
}

# Add error to validation state
__bejson_validator_add_error() {
    local message="$1"
    local location="${2:-}"
    local context="${3:-}"
    
    local error_entry="ERROR"
    [[ -n "$location" ]] && error_entry+=" | Location: $location"
    error_entry+=" | Message: $message"
    [[ -n "$context" ]] && error_entry+=" | Context: $context"
    
    __BEJSON_VALIDATION_ERRORS+=("$error_entry")
}

# Add warning to validation state
__bejson_validator_add_warning() {
    local message="$1"
    local location="${2:-}"
    
    local warning_entry="WARNING"
    [[ -n "$location" ]] && warning_entry+=" | Location: $location"
    warning_entry+=" | Message: $message"
    
    __BEJSON_VALIDATION_WARNINGS+=("$warning_entry")
}

# Get validation errors
bejson_validator_get_errors() {
    printf '%s\n' "${__BEJSON_VALIDATION_ERRORS[@]+"${__BEJSON_VALIDATION_ERRORS[@]}"}"
}

# Get validation warnings
bejson_validator_get_warnings() {
    printf '%s\n' "${__BEJSON_VALIDATION_WARNINGS[@]+"${__BEJSON_VALIDATION_WARNINGS[@]}"}"
}

# Check if validation has errors
bejson_validator_has_errors() {
    [[ ${#__BEJSON_VALIDATION_ERRORS[@]} -gt 0 ]]
}

# Check if validation has warnings
bejson_validator_has_warnings() {
    [[ ${#__BEJSON_VALIDATION_WARNINGS[@]} -gt 0 ]]
}

# Get error count
bejson_validator_error_count() {
    echo ${#__BEJSON_VALIDATION_ERRORS[@]}
}

# Get warning count
bejson_validator_warning_count() {
    echo ${#__BEJSON_VALIDATION_WARNINGS[@]}
}

#-------------------------------------------------------------------------------
# JSON SYNTAX VALIDATION
#-------------------------------------------------------------------------------

# Validate JSON syntax using jq
bejson_validator_check_json_syntax() {
    local input="$1"
    local is_file="${2:-false}"
    
    if [[ "$is_file" == "true" ]]; then
        if [[ ! -f "$input" ]]; then
            __bejson_validator_add_error "File not found: $input" "File System"
            return $E_FILE_NOT_FOUND
        fi
        __BEJSON_CURRENT_FILE="$input"
        if ! jq empty "$input" 2>/dev/null; then
            __bejson_validator_add_error "Invalid JSON syntax" "JSON Parse"
            return $E_INVALID_JSON
        fi
    else
        if ! echo "$input" | jq empty 2>/dev/null; then
            __bejson_validator_add_error "Invalid JSON syntax" "JSON Parse"
            return $E_INVALID_JSON
        fi
    fi
    return 0
}

#-------------------------------------------------------------------------------
# MANDATORY KEY VALIDATION
#-------------------------------------------------------------------------------

bejson_validator_check_mandatory_keys() {
    local json_doc="$1"
    local mandatory_keys=("Format" "Format_Version" "Format_Creator" "Records_Type" "Fields" "Values")
    
    for key in "${mandatory_keys[@]}"; do
        if ! echo "$json_doc" | jq -e "has(\"$key\")" &>/dev/null; then
            __bejson_validator_add_error "Missing mandatory top-level key: '$key'" "Top-Level Keys"
            return $E_MISSING_MANDATORY_KEY
        fi
    done
    
    local version_value=$(echo "$json_doc" | jq -r '.Format_Version // empty')
    if [[ ! "$version_value" =~ ^(104|104a|104db)$ ]]; then
        __bejson_validator_add_error "Invalid 'Format_Version': $version_value" "Top-Level Keys/Format_Version"
        return $E_INVALID_VERSION
    fi
    echo "$version_value"
    return 0
}

#-------------------------------------------------------------------------------
# FIELDS ARRAY VALIDATION
#-------------------------------------------------------------------------------

bejson_validator_check_fields_structure() {
    local json_doc="$1"
    local version="$2"
    local fields_count=$(echo "$json_doc" | jq '.Fields | length')
    
    if [[ $fields_count -eq 0 ]]; then
        __bejson_validator_add_error "'Fields' array cannot be empty" "Fields Array"
        return $E_INVALID_FIELDS
    fi
    echo "$fields_count"
    return 0
}

#-------------------------------------------------------------------------------
# RECORDS_TYPE VALIDATION
#-------------------------------------------------------------------------------

bejson_validator_check_records_type() {
    local json_doc="$1"
    local version="$2"
    local records_type_count=$(echo "$json_doc" | jq '.Records_Type | length')
    
    if [[ "$version" =~ ^(104|104a)$ ]]; then
        if [[ $records_type_count -ne 1 ]]; then
            __bejson_validator_add_error "Records_Type count must be 1 for $version" "Records_Type"
            return $E_INVALID_RECORDS_TYPE
        fi
    elif [[ "$version" == "104db" ]]; then
        if [[ $records_type_count -lt 2 ]]; then
            __bejson_validator_add_error "Records_Type count must be >= 2 for 104db" "Records_Type"
            return $E_INVALID_RECORDS_TYPE
        fi
    fi
    return 0
}

#-------------------------------------------------------------------------------
# VALUES VALIDATION
#-------------------------------------------------------------------------------

bejson_validator_check_values() {
    local json_doc="$1"
    local version="$2"
    local fields_count="$3"
    local values_count=$(echo "$json_doc" | jq '.Values | length')
    
    if [[ $values_count -eq 0 ]]; then return 0; fi
    
    # Just a sample check for length mismatch in Bash to keep it fast
    local length_mismatch=$(echo "$json_doc" | jq --argjson expected "$fields_count" '.Values | map(length == $expected) | any(false)')
    if [[ "$length_mismatch" == "true" ]]; then
         __bejson_validator_add_error "Record length mismatch detected" "Values"
         return $E_RECORD_LENGTH_MISMATCH
    fi
    return 0
}

#-------------------------------------------------------------------------------
# MAIN VALIDATION FUNCTIONS
#-------------------------------------------------------------------------------

bejson_validator_validate_string() {
    local json_string="$1"
    bejson_validator_reset_state
    bejson_validator_check_dependencies || return $?
    bejson_validator_check_json_syntax "$json_string" "false" || return $?
    local version=$(bejson_validator_check_mandatory_keys "$json_string") || return $?
    bejson_validator_check_records_type "$json_string" "$version" || return $?
    local fields_count=$(bejson_validator_check_fields_structure "$json_string" "$version") || return $?
    bejson_validator_check_values "$json_string" "$version" "$fields_count" || return $?
    return 0
}

bejson_validator_validate_file() {
    local file_path="$1"
    bejson_validator_reset_state
    bejson_validator_check_dependencies || return $?
    if [[ ! -f "$file_path" ]]; then return $E_FILE_NOT_FOUND; fi
    local file_content=$(cat "$file_path")
    bejson_validator_validate_string "$file_content"
    return $?
}

bejson_validator_get_report() {
    local input="${1:-}"
    local is_file="${2:-false}"
    if [[ "$is_file" == "true" ]]; then
        bejson_validator_validate_file "$input"
    else
        bejson_validator_validate_string "$input"
    fi
    local res=$?
    echo "=== BEJSON Validation Report ==="
    echo "Status: $([[ $res -eq 0 ]] && echo 'VALID' || echo 'INVALID')"
    bejson_validator_get_errors
    return $res
}

# Export functions
export -f bejson_validator_check_dependencies
export -f bejson_validator_reset_state
export -f bejson_validator_get_errors
export -f bejson_validator_get_warnings
export -f bejson_validator_has_errors
export -f bejson_validator_has_warnings
export -f bejson_validator_error_count
export -f bejson_validator_warning_count
export -f bejson_validator_check_json_syntax
export -f bejson_validator_check_mandatory_keys
export -f bejson_validator_check_fields_structure
export -f bejson_validator_check_records_type
export -f bejson_validator_check_values
export -f bejson_validator_validate_string
export -f bejson_validator_validate_file
export -f bejson_validator_get_report
