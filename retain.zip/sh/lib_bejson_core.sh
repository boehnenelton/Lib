#!/bin/bash
#===============================================================================
# Library:     lib_bejson_core.sh
# Jurisdiction: ["BASH", "CORE_COMMAND"]
# Status:      OFFICIAL — Core-Command/Lib (v1.1)
# Author:      Elton Boehnen
# Version:     1.1 (OFFICIAL)
# Date:        2026-04-23
# Description: BEJSON core library — document creation, mutation, validation,
atomic file I/O with sync, and query/sort utilities.
MFDB relational functions are in lib_mfdb_core.sh (decoupled).
Author:      Elton Boehnen
Version:     3.1.0 (OFFICIAL)
Date:        2026-04-16
Compat:      Bash 4.0+, Termux/Android
Requires:    lib_bejson_validator.sh (same directory), jq >= 1.6
Changelog v3.1.0:
[FIX] Atomic writes: same-partition temp files (sibling to target),
explicit `sync` before rename. Cross-filesystem fallback: cp + rm.
[FIX] Dynamic path resolution: no hard-coded paths, env var overrides.
[FIX] MFDB decoupled: relational engine moved to lib_mfdb_core.sh.
[FIX] Official status: updated to meet Core-Command/Lib standards.
Error code ranges:
1–15   → lib_bejson_validator
20–27  → lib_bejson_core
# Description: BEJSON core library — document creation, mutation, validation,
#              atomic file I/O with sync, and query/sort utilities.
#              MFDB relational functions are in lib_mfdb_core.sh (decoupled).
#
# Changelog v3.1.0:
#   [FIX] Atomic writes: same-partition temp files (sibling to target),
#         explicit `sync` before rename. Cross-filesystem fallback: cp + rm.
#   [FIX] Dynamic path resolution: no hard-coded paths, env var overrides.
#   [FIX] MFDB decoupled: relational engine moved to lib_mfdb_core.sh.
#   [FIX] Official status: updated to meet Core-Command/Lib standards.
#
# Error code ranges:
#   1–15   → lib_bejson_validator
#   20–27  → lib_bejson_core

#-------------------------------------------------------------------------------
# SAFETY & ERROR HANDLING
#-------------------------------------------------------------------------------

set -o pipefail
set -o nounset

# Source the validator library (assumes same directory)
_CORE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$_CORE_DIR/lib_bejson_validator.sh" ]]; then
    # shellcheck source=./lib_bejson_validator.sh
    source "$_CORE_DIR/lib_bejson_validator.sh"
fi

# Error codes
[[ -v E_CORE_INVALID_VERSION ]] || readonly E_CORE_INVALID_VERSION=20
[[ -v E_CORE_INVALID_OPERATION ]] || readonly E_CORE_INVALID_OPERATION=21
[[ -v E_CORE_INDEX_OUT_OF_BOUNDS ]] || readonly E_CORE_INDEX_OUT_OF_BOUNDS=22
[[ -v E_CORE_FIELD_NOT_FOUND ]] || readonly E_CORE_FIELD_NOT_FOUND=23
[[ -v E_CORE_TYPE_CONVERSION_FAILED ]] || readonly E_CORE_TYPE_CONVERSION_FAILED=24
[[ -v E_CORE_BACKUP_FAILED ]] || readonly E_CORE_BACKUP_FAILED=25
[[ -v E_CORE_WRITE_FAILED ]] || readonly E_CORE_WRITE_FAILED=26
[[ -v E_CORE_QUERY_FAILED ]] || readonly E_CORE_QUERY_FAILED=27

#-------------------------------------------------------------------------------
# ATOMIC FILE OPERATIONS
#-------------------------------------------------------------------------------

__bejson_core_atomic_backup() {
    local file_path="$1"
    [[ ! -f "$file_path" ]] && return 0
    local backup_path="${file_path}.backup.$(date +%Y%m%d_%H%M%S).$$"
    cp -p "$file_path" "$backup_path" 2>/dev/null || return $E_CORE_BACKUP_FAILED
    echo "$backup_path"
    return 0
}

__bejson_core_restore_backup() {
    local file_path="$1"
    local backup_path="$2"
    [[ -f "$backup_path" ]] && mv "$backup_path" "$file_path" 2>/dev/null
}

bejson_core_atomic_write() {
    local file_path="$1"
    local content="$2"
    local create_backup="${3:-true}"
    local backup_path=""

    if [[ "$create_backup" == "true" ]]; then
        backup_path=$(__bejson_core_atomic_backup "$file_path") || return $?
    fi

    local target_dir=$(dirname "$file_path")
    mkdir -p "$target_dir"
    local temp_file="${target_dir}/.bejson_$$.tmp"

    printf '%s' "$content" > "$temp_file" 2>/dev/null || {
        [[ -n "$backup_path" ]] && __bejson_core_restore_backup "$file_path" "$backup_path"
        return $E_CORE_WRITE_FAILED
    }

    # Explicit disk sync
    sync "$temp_file" 2>/dev/null || sync 2>/dev/null || true

    if ! bejson_validator_validate_file "$temp_file" &>/dev/null; then
        rm -f "$temp_file"
        [[ -n "$backup_path" ]] && __bejson_core_restore_backup "$file_path" "$backup_path"
        return $E_CORE_WRITE_FAILED
    fi

    if ! mv "$temp_file" "$file_path" 2>/dev/null; then
        cp -p "$temp_file" "$file_path" 2>/dev/null && rm -f "$temp_file" || {
            rm -f "$temp_file"
            [[ -n "$backup_path" ]] && __bejson_core_restore_backup "$file_path" "$backup_path"
            return $E_CORE_WRITE_FAILED
        }
    fi
    
    # Sync directory entry
    sync "$target_dir" 2>/dev/null || sync 2>/dev/null || true
    
    [[ -n "$backup_path" && -f "$backup_path" ]] && rm -f "$backup_path"
    return 0
}

#-------------------------------------------------------------------------------
# DOCUMENT CREATION
#-------------------------------------------------------------------------------

bejson_core_create_104() {
    jq -n --arg rt "$1" --argjson fields "$2" --argjson values "$3" \
        '{"Format":"BEJSON","Format_Version":"104","Format_Creator":"Elton Boehnen","Records_Type":[$rt],"Fields":$fields,"Values":$values}'
}

bejson_core_create_104db() {
    jq -n --argjson rts "$1" --argjson fields "$2" --argjson values "$3" \
        '{"Format":"BEJSON","Format_Version":"104db","Format_Creator":"Elton Boehnen","Records_Type":$rts,"Fields":$fields,"Values":$values}'
}

#-------------------------------------------------------------------------------
# DOCUMENT LOADING & UTILITIES
#-------------------------------------------------------------------------------

bejson_core_load_file() {
    bejson_validator_validate_file "$1" &>/dev/null || return 1
    cat "$1"
}

bejson_core_get_version() { echo "$1" | jq -r '.Format_Version'; }
bejson_core_get_records_types() { echo "$1" | jq -r '.Records_Type[]'; }
bejson_core_get_record_count() { echo "$1" | jq '.Values | length'; }
bejson_core_get_field_count() { echo "$1" | jq '.Fields | length'; }

bejson_core_pretty_print() { echo "$1" | jq '.'; }
bejson_core_compact_print() { echo "$1" | jq -c '.'; }

# Get records by type for 104db (strictly index 0)
bejson_core_get_records_by_type() {
    local doc="$1"
    local type="$2"
    if [[ $(bejson_core_get_version "$doc") != "104db" ]]; then
        return $E_CORE_INVALID_OPERATION
    fi
    echo "$doc" | jq --arg t "$type" '.Values | map(select(.[0] == $t))'
}

# Get field applicability with strict 104db checks
bejson_core_get_field_applicability() {
    local doc="$1"
    local field_name="$2"
    local version=$(bejson_core_get_version "$doc")
    
    local field_def=$(echo "$doc" | jq --arg name "$field_name" '.Fields[] | select(.name == $name)')
    if [[ -z "$field_def" ]]; then
        return $E_CORE_FIELD_NOT_FOUND
    fi
    
    local rtp=$(echo "$field_def" | jq -r '.Record_Type_Parent // empty')
    
    if [[ "$version" == "104db" ]]; then
        if [[ -z "$rtp" ]]; then
            local applies_to=$(echo "$field_def" | jq -r '.applies_to // empty')
            if [[ -n "$applies_to" ]]; then
                echo "Error: Field '$field_name' uses legacy 'applies_to'. 104db requires 'Record_Type_Parent'." >&2
                return $E_CORE_INVALID_OPERATION
            fi
            echo "Error: Field '$field_name' missing Record_Type_Parent in 104db" >&2
            return $E_CORE_INVALID_OPERATION
        fi
    fi
    
    echo "${rtp:-common}"
}

# Query records for exact match
bejson_core_query_records() {
    local doc="$1"
    local field_name="$2"
    local value="$3"
    local idx=$(bejson_core_get_field_index "$doc" "$field_name")
    if [[ "$idx" -lt 0 ]]; then return $E_CORE_FIELD_NOT_FOUND; fi
    echo "$doc" | jq --argjson i "$idx" --arg v "$value" '.Values | map(select(.[$i] == $v))'
}

# Sort records by field
bejson_core_sort_by_field() {
    local doc="$1"
    local field_name="$2"
    local ascending="${3:-true}"
    local idx=$(bejson_core_get_field_index "$doc" "$field_name")
    if [[ "$idx" -lt 0 ]]; then return $E_CORE_FIELD_NOT_FOUND; fi
    
    if [[ "$ascending" == "true" ]]; then
        echo "$doc" | jq --argjson i "$idx" '.Values |= sort_by(.[$i])'
    else
        echo "$doc" | jq --argjson i "$idx" '.Values |= (sort_by(.[$i]) | reverse)'
    fi
}

# Export functions
export -f bejson_core_atomic_write
export -f bejson_core_create_104
export -f bejson_core_create_104db
export -f bejson_core_load_file
export -f bejson_core_get_version
export -f bejson_core_get_records_types
export -f bejson_core_get_record_count
export -f bejson_core_get_field_count
export -f bejson_core_pretty_print
export -f bejson_core_compact_print
export -f bejson_core_get_records_by_type
export -f bejson_core_get_field_applicability
export -f bejson_core_query_records
export -f bejson_core_sort_by_field

# Get field index by name
# bejson_core_get_field_index <doc> <field_name>
bejson_core_get_field_index() {
    local doc="$1"
    local field_name="$2"
    echo "$doc" | jq --arg name "$field_name" '.Fields | map(.name == $name) | index(true) // -1'
}

# Export new function
export -f bejson_core_get_field_index

# Acquire a lock file
bejson_core_acquire_lock() {
    local file_path="$1"
    local timeout="${2:-10}"
    local lock_path="${file_path}.lock"
    local start_time=$(date +%s)

    while (( $(date +%s) - start_time < timeout )); do
        if mkdir "$lock_path" 2>/dev/null; then
            echo $$ > "${lock_path}/pid"
            return 0
        fi
        sleep 0.1
    done
    return 1
}

# Release a lock file
bejson_core_release_lock() {
    local file_path="$1"
    local lock_path="${file_path}.lock"
    rm -rf "$lock_path"
}

# Export locking functions
export -f bejson_core_acquire_lock
export -f bejson_core_release_lock

#-------------------------------------------------------------------------------
# CORE-COMMAND CONSOLIDATED HEALTH & MAINTENANCE
#-------------------------------------------------------------------------------

# Health Check and Corruption Detection
# Returns 0 on OK, 1 on Error/Corruption
bejson_core_detect_corruption() {
    local file_path="$1"
    local verbose="${2:-false}"
    
    if [[ ! -f "$file_path" ]]; then
        [[ "$verbose" == "true" ]] && echo "[CC-Health] Error: File not found at $file_path"
        return 1
    fi
    
    # Basic JSON syntax check
    if ! jq . "$file_path" &>/dev/null; then
        [[ "$verbose" == "true" ]] && echo "[CC-Health] Corruption detected: Invalid JSON in $file_path"
        return 1
    fi
    
    # Schema validation via consolidated CC validator
    if declare -F bejson_validator_validate_file &>/dev/null; then
        if ! bejson_validator_validate_file "$file_path" &>/dev/null; then
            [[ "$verbose" == "true" ]] && echo "[CC-Health] Corruption detected: BEJSON schema failure for $file_path"
            return 1
        fi
    fi
    
    return 0
}

# Individual Database Backup (Consolidated CC Structure)
# Backs up to $CC_INDIVIDUAL_DB with 5-file retention
bejson_core_backup_db() {
    local file_path="$1"
    local db_name=$(basename "$file_path")
    # Strip extensions for clean folder naming
    local clean_name="${db_name%.json}"
    clean_name="${clean_name%.bejson}"
    
    # Force use of consolidated CC_INDIVIDUAL_DB path
    local backup_root="${CC_INDIVIDUAL_DB:-/storage/7B30-0E0B/Core-Command/data/databases/backups/individual_db}"
    local target_dir="$backup_root/$clean_name"
    
    mkdir -p "$target_dir"
    local ts=$(date +%Y%m%d_%H%M%S)
    local target="$target_dir/${clean_name}_${ts}.json"
    
    if cp -p "$file_path" "$target" 2>/dev/null; then
        # Retention: Keep latest 5 in the CC consolidated folder
        ls -1t "$target_dir"/*.json 2>/dev/null | tail -n +6 | xargs rm -f 2>/dev/null
        return 0
    else
        return 1
    fi
}

export -f bejson_core_detect_corruption
export -f bejson_core_backup_db

# Recover a database from the latest individual backup
# Returns 0 on success, 1 on failure
bejson_core_recover_db() {
    local target_file="$1"
    local db_name=$(basename "$target_file")
    local clean_name="${db_name%.json}"
    clean_name="${clean_name%.bejson}"
    
    local backup_root="${CC_INDIVIDUAL_DB:-/storage/7B30-0E0B/Core-Command/data/databases/backups/individual_db}"
    local target_dir="$backup_root/$clean_name"
    
    if [[ ! -d "$target_dir" ]]; then
        return 1
    fi
    
    # Find latest backup file
    local latest=$(ls -1t "$target_dir"/*.json 2>/dev/null | head -n 1)
    
    if [[ -f "$latest" ]]; then
        # Create an emergency backup of the current (corrupt) file
        cp "$target_file" "${target_file}.corrupt.$(date +%Y%m%d_%H%M%S)" 2>/dev/null
        # Restore latest good backup
        if cp "$latest" "$target_file" 2>/dev/null; then
            return 0
        fi
    fi
    
    return 1
}

export -f bejson_core_recover_db
