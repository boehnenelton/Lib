/**
 * Library:     mfdb_core.ts
 * Jurisdiction: ["TYPESCRIPT", "CORE_COMMAND"]
 * Status:      OFFICIAL — Core-Command/Lib (v1.1)
 * Author:      Elton Boehnen
 * Version:     1.1 (OFFICIAL)
 * Date:        2026-04-23
 * Description: Core-Command library component.
 */
import {
  BEJSONDocument,
  BEJSONField,
  BEJSONValue,
  MFDBManifestRecord,
  MFDBDatabaseMeta,
  MFDBCoreError,
  MFDB_CORE_CODES as E,
} from "./bejson_types";
import { decodeManifestRecords } from "./mfdb_validators";
import {
  appendRecord,
  deleteRecord,
  getFieldIndex,
  getFieldValue,
  getRecordCount,
  setFieldValue,
  createEmpty104a,
  createEmpty104,
} from "./bejson_core";

// ---------------------------------------------------------------------------
// Manifest factory
// ---------------------------------------------------------------------------


export interface CreateManifestOptions extends MFDBDatabaseMeta {
  
  includeOptionalFields?: boolean;
}


export function createManifest(opts: CreateManifestOptions): BEJSONDocument {
  if (!opts.db_name || opts.db_name.trim() === "") {
    throw new MFDBCoreError(E.MISSING_DB_NAME, "DB_Name is required when creating a manifest.");
  }

  const includeOptional = opts.includeOptionalFields !== false;

  const fields: BEJSONField[] = [
    { name: "entity_name", type: "string" },
    { name: "file_path", type: "string" },
  ];
  if (includeOptional) {
    fields.push(
      { name: "description", type: "string" },
      { name: "record_count", type: "integer" },
      { name: "schema_version", type: "string" },
      { name: "primary_key", type: "string" }
    );
  }

  const customHeaders: Record<string, string> = {
    MFDB_Version: opts.mfdb_version ?? "1.0",
    DB_Name: opts.db_name,
  };
  if (opts.db_description) customHeaders["DB_Description"] = opts.db_description;
  if (opts.schema_version) customHeaders["Schema_Version"] = opts.schema_version;
  if (opts.author) customHeaders["Author"] = opts.author;
  if (opts.created_at) customHeaders["Created_At"] = opts.created_at;

  return createEmpty104a("mfdb", fields, customHeaders);
}

// ---------------------------------------------------------------------------
// Entity registration in the manifest
// ---------------------------------------------------------------------------


export function registerEntity(
  manifest: BEJSONDocument,
  record: MFDBManifestRecord
): BEJSONDocument {
  _assertManifest(manifest);

  // Duplicate check
  const existing = decodeManifestRecords(manifest);
  if (existing.some((r) => r.entity_name === record.entity_name)) {
    throw new MFDBCoreError(
      E.DUPLICATE_ENTITY_NAME,
      "Entity \"" + record.entity_name + "\" is already registered in the manifest."
    );
  }

  const fieldNames = manifest.Fields.map((f) => f.name);
  const row: BEJSONValue[] = fieldNames.map((name) => {
    switch (name) {
      case "entity_name": return record.entity_name;
      case "file_path": return record.file_path;
      case "description": return record.description ?? null;
      case "record_count": return record.record_count ?? null;
      case "schema_version": return record.schema_version ?? null;
      case "primary_key": return record.primary_key ?? null;
      default: return null;
    }
  });

  return appendRecord(manifest, row);
}


export function unregisterEntity(
  manifest: BEJSONDocument,
  entityName: string
): BEJSONDocument {
  _assertManifest(manifest);
  const idx = _findEntityIndex(manifest, entityName);
  return deleteRecord(manifest, idx);
}


export function syncRecordCount(
  manifest: BEJSONDocument,
  entityName: string,
  count: number
): BEJSONDocument {
  _assertManifest(manifest);
  const idx = _findEntityIndex(manifest, entityName);

  let rcField: string;
  try {
    getFieldIndex(manifest, "record_count");
    rcField = "record_count";
  } catch {
    throw new MFDBCoreError(
      E.RECORD_COUNT_SYNC_FAILED,
      "Manifest Fields does not include \"record_count\" — cannot sync for entity \"" + entityName + "\"."
    );
  }

  return setFieldValue(manifest, idx, rcField, count);
}


export function updateEntityRecord(
  manifest: BEJSONDocument,
  entityName: string,
  updates: Partial<MFDBManifestRecord>
): BEJSONDocument {
  _assertManifest(manifest);
  const idx = _findEntityIndex(manifest, entityName);
  let updated = manifest;

  for (const [key, value] of Object.entries(updates)) {
    if (key === "entity_name") continue; // entity_name is the identity key, skip
    try {
      getFieldIndex(updated, key); // will throw if field not declared
      updated = setFieldValue(updated, idx, key, value as BEJSONValue);
    } catch {
      // Field not present in this manifest — silently skip
    }
  }

  return updated;
}

// ---------------------------------------------------------------------------
// Entity file factory (convenience wrapper)
// ---------------------------------------------------------------------------


export function createEntityFile(
  entityName: string,
  fields: BEJSONField[],
  parentHierarchy: string
): BEJSONDocument {
  if (!parentHierarchy || parentHierarchy.trim() === "") {
    throw new MFDBCoreError(
      E.NULL_ENTITY,
      "parentHierarchy must be a non-empty string pointing to the manifest."
    );
  }
  return createEmpty104(entityName, fields, parentHierarchy);
}

// ---------------------------------------------------------------------------
// Manifest lookup helpers
// ---------------------------------------------------------------------------


export function findEntityRecord(
  manifest: BEJSONDocument,
  entityName: string
): MFDBManifestRecord | null {
  _assertManifest(manifest);
  const records = decodeManifestRecords(manifest);
  return records.find((r) => r.entity_name === entityName) ?? null;
}


export function listEntities(manifest: BEJSONDocument): MFDBManifestRecord[] {
  _assertManifest(manifest);
  return decodeManifestRecords(manifest);
}


export function listEntityPaths(manifest: BEJSONDocument): string[] {
  _assertManifest(manifest);
  return decodeManifestRecords(manifest).map((r) => r.file_path);
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function _assertManifest(doc: BEJSONDocument): void {
  if (doc === null || doc === undefined) {
    throw new MFDBCoreError(E.NULL_MANIFEST, "Manifest document is null or undefined.");
  }
}

function _findEntityIndex(manifest: BEJSONDocument, entityName: string): number {
  const enIdx = getFieldIndex(manifest, "entity_name");
  for (let i = 0; i < manifest.Values.length; i++) {
    if (manifest.Values[i][enIdx] === entityName) return i;
  }
  throw new MFDBCoreError(
    E.ENTITY_NOT_IN_MANIFEST,
    "Entity \"" + entityName + "\" is not registered in the manifest."
  );
}
