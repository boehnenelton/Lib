/**
 * Library:     lib_mfdb_core.js
 * Jurisdiction: ["JAVASCRIPT", "CORE_COMMAND"]
 * Status:      OFFICIAL — Core-Command/Lib (v1.1)
 * Author:      Elton Boehnen
 * Version:     1.1 (OFFICIAL)
 * Date:        2026-04-23
 * Description: MFDB (Multifile Database) core operations — JavaScript port.
Layers on lib_bejson_core.js and lib_mfdb_validator.js.
Provides create, read, write, query, join, and sync
operations across MFDB entity files and their manifest.
Author:      Elton Boehnen
Version:     2.0.0 (OFFICIAL)
Date:        2026-04-16
Requires:    lib_bejson_core.js, lib_mfdb_validator.js (same directory)
* Changelog v2.0.0:
[NEW] Decoupled from lib_bejson_core.js — standalone MFDB engine.
Unidirectional dependency: MFDB → core (not vice versa).
* Error code ranges:
1–15   → lib_bejson_validator  (BEJSONValidationError)
20–27  → lib_bejson_core       (BEJSONCoreError)
30–49  → lib_mfdb_validator    (MFDBValidationError)
50–69  → lib_mfdb_core         (MFDBCoreError)         ← this file
 */
'use strict';

const {
  BEJSONCoreError,
  bejson_core_atomic_write,
  bejson_core_add_record,
  bejson_core_remove_record,
  bejson_core_update_field,
  bejson_core_load_file,
  bejson_core_get_record_count,
  bejson_core_filter_rows,
  bejson_core_sort_by_field,
  bejson_core_get_field_index,
} = (typeof require !== 'undefined')
  ? require('./lib_bejson_core.js')
  : window.BEJSON_CORE;

const {
  MFDBValidationError,
  mfdb_validator_validate_manifest,
  mfdb_validator_validate_entity_file,
  _loadJson,
  _rowsAsDicts,
  _resolveEntityPath,
  _fileExists,
} = (typeof require !== 'undefined')
  ? require('./lib_mfdb_validator.js')
  : window.MFDB_VALIDATOR;

// ---------------------------------------------------------------------------
// Error codes (50–69)
// ---------------------------------------------------------------------------

const E_MFDB_CORE_MANIFEST_NOT_FOUND   = 50;
const E_MFDB_CORE_ENTITY_NOT_FOUND     = 51;
const E_MFDB_CORE_WRITE_FAILED         = 52;
const E_MFDB_CORE_CREATE_FAILED        = 53;
const E_MFDB_CORE_INVALID_OPERATION    = 54;
const E_MFDB_CORE_INDEX_OUT_OF_BOUNDS  = 55;
const E_MFDB_CORE_JOIN_FAILED          = 56;

class MFDBCoreError extends Error {
  
  constructor(message, code) {
    super(message);
    this.name = 'MFDBCoreError';
    this.code = code;
  }
}


// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function _getManifestEntries(manifestPath) {
  const doc = _loadJson(manifestPath);
  return _rowsAsDicts(doc);
}

function _getManifestEntry(manifestPath, entityName) {
  const entries = _getManifestEntries(manifestPath);
  const entry   = entries.find(e => e.entity_name === entityName);
  if (!entry) {
    throw new MFDBCoreError(
      `Entity '${entityName}' not found in manifest: ${manifestPath}`,
      E_MFDB_CORE_ENTITY_NOT_FOUND,
    );
  }
  return entry;
}

function _getEntityPath(manifestPath, entityName) {
  const entry = _getManifestEntry(manifestPath, entityName);
  return _resolveEntityPath(manifestPath, entry.file_path);
}

function _loadEntityDoc(manifestPath, entityName) {
  const entityPath = _getEntityPath(manifestPath, entityName);
  return bejson_core_load_file(entityPath);
}

function _writeEntityDoc(doc, entityPath) {
  bejson_core_atomic_write(entityPath, doc);
}

function _writeManifestDoc(doc, manifestPath) {
  bejson_core_atomic_write(manifestPath, doc);
}

function _updateManifestRecordCount(manifestPath, entityName, count) {
  const doc     = _loadJson(manifestPath);
  const fnList  = doc.Fields.map(f => f.name);
  if (!fnList.includes('record_count') || !fnList.includes('entity_name')) return;
  const rcIdx = fnList.indexOf('record_count');
  const enIdx = fnList.indexOf('entity_name');
  for (const row of doc.Values) {
    if (row[enIdx] === entityName) {
      row[rcIdx] = count;
      break;
    }
  }
  _writeManifestDoc(doc, manifestPath);
}


// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------


function mfdb_core_discover(filePath) {
  const path = require('path');
  if (!_fileExists(filePath)) {
    throw new MFDBCoreError(`File not found: ${filePath}`, E_MFDB_CORE_MANIFEST_NOT_FOUND);
  }

  let doc;
  try { doc = _loadJson(filePath); } catch (_) { return 'standalone'; }

  const version  = doc.Format_Version || '';
  const filename = path.basename(filePath);

  if (version === '104a' && filename.endsWith('.mfdb.bejson')) return 'manifest';
  if (version === '104'  && doc.Parent_Hierarchy)              return 'entity';
  return 'standalone';
}


// ---------------------------------------------------------------------------
// Read operations
// ---------------------------------------------------------------------------


function mfdb_core_load_manifest(manifestPath) {
  mfdb_validator_validate_manifest(manifestPath);
  return _getManifestEntries(manifestPath);
}


function mfdb_core_load_entity(manifestPath, entityName) {
  const doc = _loadEntityDoc(manifestPath, entityName);
  return _rowsAsDicts(doc);
}


function mfdb_core_get_entity_doc(manifestPath, entityName) {
  return _loadEntityDoc(manifestPath, entityName);
}


function mfdb_core_get_stats(manifestPath) {
  const doc     = _loadJson(manifestPath);
  const entries = _rowsAsDicts(doc);

  const entityStats = entries.map(entry => {
    const resolved = _resolveEntityPath(manifestPath, entry.file_path);
    let recCount = -1, fieldCount = -1;
    if (_fileExists(resolved)) {
      const edoc = _loadJson(resolved);
      recCount   = (edoc.Values  || []).length;
      fieldCount = (edoc.Fields  || []).length;
    }
    return {
      entity_name:  entry.entity_name,
      file_path:    entry.file_path,
      record_count: recCount,
      field_count:  fieldCount,
      primary_key:  entry.primary_key || null,
    };
  });

  return {
    db_name:        doc.DB_Name        || '',
    schema_version: doc.Schema_Version || '',
    entity_count:   entries.length,
    entities:       entityStats,
  };
}


// ---------------------------------------------------------------------------
// Query operations
// ---------------------------------------------------------------------------


function mfdb_core_query_entity(manifestPath, entityName, predicate) {
  const records = mfdb_core_load_entity(manifestPath, entityName);
  return records.filter(predicate);
}


function mfdb_core_build_index(manifestPath, entityName, fieldName) {
  const records = mfdb_core_load_entity(manifestPath, entityName);
  const index   = {};
  for (const r of records) {
    if (r[fieldName] != null) index[r[fieldName]] = r;
  }
  return index;
}


function mfdb_core_join(manifestPath, fromEntity, toEntity, fromFk, toPk) {
  const fromRecords = mfdb_core_load_entity(manifestPath, fromEntity);
  const toIndex     = mfdb_core_build_index(manifestPath, toEntity, toPk);

  return fromRecords.map(record => {
    const fkVal  = record[fromFk];
    const target = toIndex[fkVal] || {};
    const merged = { ...record };
    for (const [k, v] of Object.entries(target)) {
      merged[`${toEntity}__${k}`] = v;
    }
    return merged;
  });
}


// ---------------------------------------------------------------------------
// Write operations
// ---------------------------------------------------------------------------


function mfdb_core_add_entity_record(manifestPath, entityName, values, syncCount = true) {
  const entityPath = _getEntityPath(manifestPath, entityName);
  let doc          = bejson_core_load_file(entityPath);
  doc              = bejson_core_add_record(doc, values);
  _writeEntityDoc(doc, entityPath);
  if (syncCount) {
    _updateManifestRecordCount(manifestPath, entityName, doc.Values.length);
  }
  return doc;
}


function mfdb_core_remove_entity_record(manifestPath, entityName, recordIndex, syncCount = true) {
  const entityPath = _getEntityPath(manifestPath, entityName);
  let doc          = bejson_core_load_file(entityPath);
  doc              = bejson_core_remove_record(doc, recordIndex);
  _writeEntityDoc(doc, entityPath);
  if (syncCount) {
    _updateManifestRecordCount(manifestPath, entityName, doc.Values.length);
  }
  return doc;
}


function mfdb_core_update_entity_record(manifestPath, entityName, recordIndex, fieldName, newValue) {
  const entityPath = _getEntityPath(manifestPath, entityName);
  let doc          = bejson_core_load_file(entityPath);
  doc              = bejson_core_update_field(doc, recordIndex, fieldName, newValue);
  _writeEntityDoc(doc, entityPath);
  return doc;
}


// ---------------------------------------------------------------------------
// Manifest sync
// ---------------------------------------------------------------------------


function mfdb_core_sync_manifest_count(manifestPath, entityName) {
  const entityPath = _getEntityPath(manifestPath, entityName);
  const edoc       = _loadJson(entityPath);
  const count      = (edoc.Values || []).length;
  _updateManifestRecordCount(manifestPath, entityName, count);
  return count;
}


function mfdb_core_sync_all_counts(manifestPath) {
  const entries = _getManifestEntries(manifestPath);
  const results = {};
  for (const entry of entries) {
    const name    = entry.entity_name;
    results[name] = mfdb_core_sync_manifest_count(manifestPath, name);
  }
  return results;
}


// ---------------------------------------------------------------------------
// Database creation
// ---------------------------------------------------------------------------


function mfdb_core_create_entity_file(
  manifestPath,
  entityName,
  fields,
  description   = '',
  primaryKey    = '',
  schemaVersion = '1.0',
  filePathRel   = '',
) {
  const fs   = require('fs');
  const path = require('path');

  const manifestDir = path.dirname(path.resolve(manifestPath));

  if (!filePathRel) filePathRel = `data/${entityName.toLowerCase()}.bejson`;

  const resolved  = path.resolve(manifestDir, filePathRel);
  const entityDir = path.dirname(resolved);
  fs.mkdirSync(entityDir, { recursive: true });

  const relToManifest = path.relative(entityDir, path.resolve(manifestPath));

  const entityDoc = {
    Format:           'BEJSON',
    Format_Version:   '104',
    Format_Creator:   'Elton Boehnen',
    Parent_Hierarchy: relToManifest,
    Records_Type:     [entityName],
    Fields:           fields,
    Values:           [],
  };
  bejson_core_atomic_write(resolved, entityDoc);

  // Append record to manifest.
  const manifestDoc = _loadJson(manifestPath);
  const fnList      = manifestDoc.Fields.map(f => f.name);
  const newRow      = fnList.map(fn => {
    if (fn === 'entity_name')    return entityName;
    if (fn === 'file_path')      return filePathRel;
    if (fn === 'description')    return description || null;
    if (fn === 'record_count')   return 0;
    if (fn === 'schema_version') return schemaVersion;
    if (fn === 'primary_key')    return primaryKey || null;
    return null;
  });
  manifestDoc.Values.push(newRow);
  _writeManifestDoc(manifestDoc, manifestPath);

  return resolved;
}


function mfdb_core_create_database(
  rootDir,
  dbName,
  entities,
  dbDescription = '',
  schemaVersion = '1.0.0',
  author        = 'Elton Boehnen',
  mfdbVersion   = '1.0',
) {
  const fs   = require('fs');
  const path = require('path');

  fs.mkdirSync(rootDir, { recursive: true });
  const manifestPath = path.join(rootDir, '104a.mfdb.bejson');

  const manifestFields = [
    { name: 'entity_name',    type: 'string'  },
    { name: 'file_path',      type: 'string'  },
    { name: 'description',    type: 'string'  },
    { name: 'record_count',   type: 'integer' },
    { name: 'schema_version', type: 'string'  },
    { name: 'primary_key',    type: 'string'  },
  ];

  const manifestValues  = [];
  const entityDefsToFile = [];

  for (const entity of entities) {
    const name   = entity.name;
    const fpRel  = entity.file_path || `data/${name.toLowerCase()}.bejson`;
    const desc   = entity.description   || '';
    const pk     = entity.primary_key   || '';
    const sv     = entity.schema_version || '1.0';

    manifestValues.push([name, fpRel, desc || null, 0, sv, pk || null]);
    entityDefsToFile.push({ name, fpRel, fields: entity.fields });
  }

  const createdAt   = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');

  const manifestDoc = {
    Format:         'BEJSON',
    Format_Version: '104a',
    Format_Creator: 'Elton Boehnen',
    MFDB_Version:   mfdbVersion,
    DB_Name:        dbName,
    DB_Description: dbDescription,
    Schema_Version: schemaVersion,
    Author:         author,
    Created_At:     createdAt,
    Records_Type:   ['mfdb'],
    Fields:         manifestFields,
    Values:         manifestValues,
  };

  bejson_core_atomic_write(manifestPath, manifestDoc);

  for (const { name, fpRel, fields } of entityDefsToFile) {
    const resolved  = path.resolve(rootDir, fpRel);
    const entityDir = path.dirname(resolved);
    fs.mkdirSync(entityDir, { recursive: true });

    const relToManifest = path.relative(entityDir, path.resolve(manifestPath));

    const entityDoc = {
      Format:           'BEJSON',
      Format_Version:   '104',
      Format_Creator:   'Elton Boehnen',
      Parent_Hierarchy: relToManifest,
      Records_Type:     [name],
      Fields:           fields,
      Values:           [],
    };
    bejson_core_atomic_write(resolved, entityDoc);
  }

  return manifestPath;
}


// ---------------------------------------------------------------------------
// Exports (CommonJS + browser global)
// ---------------------------------------------------------------------------

const exports_ = {
  // Error codes
  E_MFDB_CORE_MANIFEST_NOT_FOUND,
  E_MFDB_CORE_ENTITY_NOT_FOUND,
  E_MFDB_CORE_WRITE_FAILED,
  E_MFDB_CORE_CREATE_FAILED,
  E_MFDB_CORE_INVALID_OPERATION,
  E_MFDB_CORE_INDEX_OUT_OF_BOUNDS,
  E_MFDB_CORE_JOIN_FAILED,
  // Class
  MFDBCoreError,
  // Discovery
  mfdb_core_discover,
  // Read
  mfdb_core_load_manifest,
  mfdb_core_load_entity,
  mfdb_core_get_entity_doc,
  mfdb_core_get_stats,
  // Query
  mfdb_core_query_entity,
  mfdb_core_build_index,
  mfdb_core_join,
  // Write
  mfdb_core_add_entity_record,
  mfdb_core_remove_entity_record,
  mfdb_core_update_entity_record,
  // Sync
  mfdb_core_sync_manifest_count,
  mfdb_core_sync_all_counts,
  // Creation
  mfdb_core_create_entity_file,
  mfdb_core_create_database,
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = exports_;
}
if (typeof window !== 'undefined') {
  window.MFDB_CORE = exports_;
}
