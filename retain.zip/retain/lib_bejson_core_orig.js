
/**

* Library: lib_bejson_validator.js
* Description: BEJSON validation library — JavaScript/Node.js port
* Author: BEJSON Core Team
* Version: 1.0.0
*/

const fs = require('fs');
const path = require('path');

// ---------------------------------------------------------------------------
// Error codes
// ---------------------------------------------------------------------------
const E_INVALID_JSON = 1;
const E_MISSING_MANDATORY_KEY = 2;
const E_INVALID_FORMAT = 3;
const E_INVALID_VERSION = 4;
const E_INVALID_RECORDS_TYPE = 5;
const E_INVALID_FIELDS = 6;
const E_INVALID_VALUES = 7;
const E_TYPE_MISMATCH = 8;
const E_RECORD_LENGTH_MISMATCH = 9;
const E_RESERVED_KEY_COLLISION = 10;
const E_INVALID_RECORD_TYPE_PARENT = 11;
const E_NULL_VIOLATION = 12;
const E_FILE_NOT_FOUND = 13;
const E_PERMISSION_DENIED = 14;
const E_ATOMIC_WRITE_FAILED = 15;

const VALID_VERSIONS = new Set(["104", "104a", "104db"]);
const MANDATORY_KEYS = ["Format", "Format_Version", "Format_Creator", "Records_Type", "Fields", "Values"];
const VALID_FIELD_TYPES = new Set(["string", "integer", "number", "boolean", "array", "object"]);

// ---------------------------------------------------------------------------
// Validation exception
// ---------------------------------------------------------------------------
class BEJSONValidationError extends Error {
constructor(message, code) {
super(message);
this.name = "BEJSONValidationError";
this.code = code;
}
}

// ---------------------------------------------------------------------------
// Validation state
// ---------------------------------------------------------------------------
const state = {
errors: [],
warnings: [],
currentFile: "",
reset() {
this.errors = [];
this.warnings = [];
this.currentFile = "";
},
addError(message, location = "", context = "") {
let entry = "ERROR";
if (location) entry += ` | Location: ${location}`;
entry += ` | Message: ${message}`;
if (context) entry += ` | Context: ${context}`;
this.errors.push(entry);
},
addWarning(message, location = "") {
let entry = "WARNING";
if (location) entry += ` | Location: ${location}`;
entry += ` | Message: ${message}`;
this.warnings.push(entry);
}
};

// ---------------------------------------------------------------------------
// Internal helper
// ---------------------------------------------------------------------------
function _jsonType(value) {
if (value === null) return "null";
if (Array.isArray(value)) return "array";
if (typeof value === "boolean") return "boolean";
if (typeof value === "string") return "string";
if (typeof value === "number") return Number.isInteger(value) ? "integer" : "number";
if (typeof value === "object") return "object";
return "unknown";
}

// ---------------------------------------------------------------------------
// Core Validation Functions
// ---------------------------------------------------------------------------
const validator = {
getErrors: () => [...state.errors],
getWarnings: () => [...state.warnings],
hasErrors: () => state.errors.length > 0,
hasWarnings: () => state.warnings.length > 0,
errorCount: () => state.errors.length,
warningCount: () => state.warnings.length,
resetState: () => state.reset(),

```
checkJsonSyntax(input, isFile = false) {
    let text = input;
    if (isFile) {
        if (!fs.existsSync(input)) {
            state.addError(`File not found: ${input}`, "File System");
            throw new BEJSONValidationError("File not found", E_FILE_NOT_FOUND);
        }
        try {
            text = fs.readFileSync(input, 'utf-8');
        } catch (err) {
            state.addError(`Permission denied or read error: ${input}`, "File System");
            throw new BEJSONValidationError("Permission denied", E_PERMISSION_DENIED);
        }
        state.currentFile = input;
    }

    if (typeof text === 'object') return text;

    try {
        return JSON.parse(text);
    } catch (err) {
        state.addError(`Invalid JSON syntax: ${err.message}`, "JSON Parse");
        throw new BEJSONValidationError("Invalid JSON", E_INVALID_JSON);
    }
},

checkMandatoryKeys(doc) {
    for (const key of MANDATORY_KEYS) {
        if (!(key in doc)) {
            state.addError(`Missing mandatory top-level key: '${key}'`, "Top-Level Keys");
            throw new BEJSONValidationError(`Missing mandatory key: ${key}`, E_MISSING_MANDATORY_KEY);
        }
    }

    if (doc.Format !== "BEJSON") {
        state.addError(`Invalid 'Format' value: Expected 'BEJSON', got '${doc.Format}'`, "Top-Level Keys/Format");
        throw new BEJSONValidationError("Invalid Format", E_INVALID_FORMAT);
    }

    const version = doc.Format_Version;
    if (!VALID_VERSIONS.has(version)) {
        state.addError(`Invalid 'Format_Version': Expected '104', '104a', or '104db', got '${version}'`, "Top-Level Keys/Format_Version");
        throw new BEJSONValidationError("Invalid Version", E_INVALID_VERSION);
    }

    if (typeof doc.Format_Creator !== "string") {
        state.addError("Invalid 'Format_Creator': Must be a string", "Top-Level Keys/Format_Creator");
        throw new BEJSONValidationError("Invalid Format_Creator", E_INVALID_FORMAT);
    }

    if (!Array.isArray(doc.Records_Type)) throw new BEJSONValidationError("Records_Type must be array", E_INVALID_RECORDS_TYPE);
    if (!Array.isArray(doc.Fields)) throw new BEJSONValidationError("Fields must be array", E_INVALID_FIELDS);
    if (!Array.isArray(doc.Values)) throw new BEJSONValidationError("Values must be array", E_INVALID_VALUES);

    return version;
},

checkFieldsStructure(doc, version) {
    const fields = doc.Fields;
    if (fields.length === 0) {
        state.addError("'Fields' array cannot be empty", "Fields Array");
        throw new BEJSONValidationError("Empty Fields", E_INVALID_FIELDS);
    }

    const seenNames = new Set();
    for (let i = 0; i < fields.length; i++) {
        const f = fields[i];
        if (!f || typeof f !== "object" || Array.isArray(f)) {
            state.addError(`Field at index ${i} must be an object`, `Fields[${i}]`);
            throw new BEJSONValidationError("Field not object", E_INVALID_FIELDS);
        }

        const name = f.name;
        if (typeof name !== "string") {
            state.addError(`Field at index ${i}: Missing or invalid 'name' (must be string)`, `Fields[${i}]`);
            throw new BEJSONValidationError("Invalid field name", E_INVALID_FIELDS);
        }

        if (seenNames.has(name)) {
            state.addError(`Duplicate field name '${name}' found in 'Fields' array`, `Fields[${i}]`);
            throw new BEJSONValidationError("Duplicate field", E_INVALID_FIELDS);
        }
        seenNames.add(name);

        const type = f.type;
        if (typeof type !== "string" || !VALID_FIELD_TYPES.has(type)) {
            state.addError(`Field '${name}' (index ${i}): Invalid type '${type}'`, `Fields[${i}]`);
            throw new BEJSONValidationError("Invalid field type", E_INVALID_FIELDS);
        }

        if (version === "104a" && (type === "array" || type === "object")) {
            state.addError(`Field '${name}' (index ${i}): Type '${type}' not allowed in 104a.`, `Fields[${i}]`);
            throw new BEJSONValidationError("Disallowed type for 104a", E_INVALID_FIELDS);
        }
    }
    return fields.length;
},

checkRecordsType(doc, version) {
    const rt = doc.Records_Type;
    if (version === "104" || version === "104a") {
        if (rt.length !== 1 || typeof rt[0] !== "string") {
            state.addError(`For BEJSON ${version}, 'Records_Type' must contain exactly one string.`, "Records_Type");
            throw new BEJSONValidationError("Bad Records_Type", E_INVALID_RECORDS_TYPE);
        }
    } else if (version === "104db") {
        if (rt.length < 2) {
            state.addError(`For BEJSON 104db, 'Records_Type' must contain two or more unique strings.`, "Records_Type");
            throw new BEJSONValidationError("Bad Records_Type", E_INVALID_RECORDS_TYPE);
        }
        const seen = new Set();
        for (let i = 0; i < rt.length; i++) {
            if (typeof rt[i] !== "string") {
                state.addError(`Records_Type[${i}] must be a string`, `Records_Type[${i}]`);
                throw new BEJSONValidationError("Bad Records_Type entry", E_INVALID_RECORDS_TYPE);
            }
            if (seen.has(rt[i])) {
                state.addError(`Duplicate type '${rt[i]}' found in 'Records_Type'`, "Records_Type");
                throw new BEJSONValidationError("Duplicate Records_Type", E_INVALID_RECORDS_TYPE);
            }
            seen.add(rt[i]);
        }
    }
},

checkRecordTypeParent(doc) {
    const fields = doc.Fields;
    if (!fields.length || fields[0].name !== "Record_Type_Parent" || fields[0].type !== "string") {
        state.addError(`For BEJSON 104db, the first field must be {"name": "Record_Type_Parent", "type": "string"}.`, "Fields[0]");
        throw new BEJSONValidationError("Bad Record_Type_Parent field", E_INVALID_RECORD_TYPE_PARENT);
    }

    const validTypes = new Set(doc.Records_Type);
    for (let i = 0; i < doc.Values.length; i++) {
        const record = doc.Values[i];
        if (!Array.isArray(record)) throw new BEJSONValidationError("Bad record", E_INVALID_VALUES);
        
        const rtp = record[0];
        if (!rtp) {
            state.addError(`Record at 'Values' index ${i}: 'Record_Type_Parent' is missing or null`, `Values[${i}][0]`);
            throw new BEJSONValidationError("Missing RTP", E_INVALID_RECORD_TYPE_PARENT);
        }
        if (!validTypes.has(rtp)) {
            state.addError(`Record at 'Values' index ${i}: 'Record_Type_Parent' value '${rtp}' does not match any declared type`, `Values[${i}][0]`);
            throw new BEJSONValidationError("Invalid RTP", E_INVALID_RECORD_TYPE_PARENT);
        }
    }
},

checkValues(doc, version, fieldsCount) {
    const values = doc.Values;
    const fields = doc.Fields;

    for (let i = 0; i < values.length; i++) {
        const record = values[i];
        if (!Array.isArray(record)) {
            state.addError(`Values[${i}] must be an array`, `Values[${i}]`);
            throw new BEJSONValidationError("Bad record", E_INVALID_VALUES);
        }

        if (record.length !== fieldsCount) {
            state.addError(`Record at 'Values' index ${i} has ${record.length} elements, expected ${fieldsCount}.`, `Values[${i}]`);
            throw new BEJSONValidationError("Length mismatch", E_RECORD_LENGTH_MISMATCH);
        }

        const recordType = (version === "104db" && record.length > 0) ? record[0] : null;

        for (let j = 0; j < record.length; j++) {
            const val = record[j];
            const fieldDef = fields[j];
            const fName = fieldDef.name;
            const fType = fieldDef.type;
            const fParent = fieldDef.Record_Type_Parent;

            // 104db strict null enforcement for inapplicable fields
            if (version === "104db" && fParent && j > 0) {
                if (fParent !== recordType) {
                    if (val !== null) {
                        state.addError(`Record ${i} (type '${recordType}'), field '${fName}': not applicable, must be null.`, `Values[${i}][${j}]`);
                        throw new BEJSONValidationError("Null violation", E_NULL_VIOLATION);
                    }
                    continue;
                }
            }

            if (val === null) continue;

            const actualType = _jsonType(val);
            let isValid = false;

            if (fType === "string") isValid = (actualType === "string");
            else if (fType === "integer") isValid = (actualType === "integer");
            else if (fType === "number") isValid = (actualType === "number" || actualType === "integer");
            else if (fType === "boolean") isValid = (actualType === "boolean");
            else if (fType === "array") isValid = (actualType === "array");
            else if (fType === "object") isValid = (actualType === "object");

            if (!isValid) {
                state.addError(`Record ${i}, field '${fName}': Value is '${actualType}', expected '${fType}'.`, `Values[${i}][${j}]`);
                throw new BEJSONValidationError("Type mismatch", E_TYPE_MISMATCH);
            }
        }
    }
},

checkCustomHeaders(doc, version) {
    const mandatory = new Set(MANDATORY_KEYS);
    const pascalCase = /^[A-Z][a-zA-Z0-9_]*$/;

    for (const key of Object.keys(doc)) {
        if (mandatory.has(key)) continue;

        if (version === "104" || version === "104db") {
            // EXCEPTION: 104 allows Parent_Hierarchy
            if (version === "104" && key === "Parent_Hierarchy") continue;
            
            state.addError(`For BEJSON ${version}, custom top-level key '${key}' is not permitted.`, `Top-Level Keys/${key}`);
            throw new BEJSONValidationError("Unexpected key", E_RESERVED_KEY_COLLISION);
        }

        if (version === "104a" && !pascalCase.test(key)) {
            state.addWarning(`Custom top-level key '${key}' does not follow recommended PascalCase naming.`, `Top-Level Keys/${key}`);
        }
    }
},

validateString(jsonString) {
    this.resetState();
    const doc = this.checkJsonSyntax(jsonString, false);
    const version = this.checkMandatoryKeys(doc);
    this.checkCustomHeaders(doc, version);
    this.checkRecordsType(doc, version);
    const count = this.checkFieldsStructure(doc, version);
    if (version === "104db") this.checkRecordTypeParent(doc);
    this.checkValues(doc, version, count);
    return true;
},

validateFile(filePath) {
    this.resetState();
    const doc = this.checkJsonSyntax(filePath, true);
    const version = this.checkMandatoryKeys(doc);
    this.checkCustomHeaders(doc, version);
    this.checkRecordsType(doc, version);
    const count = this.checkFieldsStructure(doc, version);
    if (version === "104db") this.checkRecordTypeParent(doc);
    this.checkValues(doc, version, count);
    return true;
},

getReport(input, isFile = false) {
    let valid = false;
    try {
        valid = isFile ? this.validateFile(input) : this.validateString(input);
    } catch (e) {
        // caught validation error
    }

    const lines = [
        "=== BEJSON Validation Report ===",
        `Status: ${valid ? 'VALID' : 'INVALID'}`,
        "",
        `Errors: ${this.errorCount()}`
    ];
    
    if (this.hasErrors()) {
        lines.push("---");
        lines.push(...this.getErrors());
    }

    lines.push("", `Warnings: ${this.warningCount()}`);
    if (this.hasWarnings()) {
        lines.push("---");
        lines.push(...this.getWarnings());
    }

    return lines.join("\n");
}

```

};

module.exports = {
BEJSONValidationError,
validator,
ERRORS: {
E_INVALID_JSON, E_MISSING_MANDATORY_KEY, E_INVALID_FORMAT, E_INVALID_VERSION,
E_INVALID_RECORDS_TYPE, E_INVALID_FIELDS, E_INVALID_VALUES, E_TYPE_MISMATCH,
E_RECORD_LENGTH_MISMATCH, E_RESERVED_KEY_COLLISION, E_INVALID_RECORD_TYPE_PARENT,
E_NULL_VIOLATION, E_FILE_NOT_FOUND, E_PERMISSION_DENIED, E_ATOMIC_WRITE_FAILED
}
};

lib-bejson_core.js
/**

* Library: lib-bejson_core.js
* Description: Core BEJSON manipulation library — JavaScript/Node.js port
* Author: BEJSON Core Team
* Version: 1.0.0
*/

const fs = require('fs');
const path = require('path');
const { validator, BEJSONValidationError } = require('./lib-bejson_validator.js');

// ---------------------------------------------------------------------------
// Error codes
// ---------------------------------------------------------------------------
const E_CORE_INVALID_VERSION = 20;
const E_CORE_INVALID_OPERATION = 21;
const E_CORE_INDEX_OUT_OF_BOUNDS = 22;
const E_CORE_FIELD_NOT_FOUND = 23;
const E_CORE_TYPE_CONVERSION_FAILED = 24;
const E_CORE_BACKUP_FAILED = 25;
const E_CORE_WRITE_FAILED = 26;
const E_CORE_QUERY_FAILED = 27;

class BEJSONCoreError extends Error {
constructor(message, code) {
super(message);
this.name = "BEJSONCoreError";
this.code = code;
}
}

// ---------------------------------------------------------------------------
// Internal deep copy
// ---------------------------------------------------------------------------
function _clone(obj) {
return JSON.parse(JSON.stringify(obj));
}

// ---------------------------------------------------------------------------
// Atomic File Operations
// ---------------------------------------------------------------------------
function atomicBackup(filePath, backupSuffix = ".backup") {
if (!fs.existsSync(filePath)) return "";

```
const timestamp = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 15);
const backupPath = `${filePath}${backupSuffix}.${timestamp}`;

try {
    fs.copyFileSync(filePath, backupPath);
} catch (err) {
    throw new BEJSONCoreError(`Backup failed: ${err.message}`, E_CORE_BACKUP_FAILED);
}
return backupPath;

```

}

function restoreBackup(filePath, backupPath) {
if (fs.existsSync(backupPath)) {
fs.renameSync(backupPath, filePath);
return true;
}
return false;
}

function atomicWrite(filePath, content, createBackup = true) {
let backupPath = "";
if (createBackup) {
backupPath = atomicBackup(filePath);
}

```
const jsonText = JSON.stringify(content, null, 2);
const tmpPath = `${filePath}.tmp.${Date.now()}`;

try {
    fs.writeFileSync(tmpPath, jsonText, 'utf-8');
} catch (err) {
    if (backupPath) restoreBackup(filePath, backupPath);
    throw new BEJSONCoreError(`Write failed: ${err.message}`, E_CORE_WRITE_FAILED);
}

try {
    validator.validateFile(tmpPath);
} catch (err) {
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    if (backupPath) restoreBackup(filePath, backupPath);
    throw new BEJSONCoreError(`Validation failed: ${err.message}`, E_CORE_WRITE_FAILED);
}

try {
    fs.renameSync(tmpPath, filePath);
} catch (err) {
    if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    if (backupPath) restoreBackup(filePath, backupPath);
    throw new BEJSONCoreError(`Atomic move failed: ${err.message}`, E_CORE_WRITE_FAILED);
}

if (backupPath && fs.existsSync(backupPath)) {
    fs.unlinkSync(backupPath);
}

```

}

// ---------------------------------------------------------------------------
// Document Creation
// ---------------------------------------------------------------------------
function create104(recordsType, fields, values) {
return {
Format: "BEJSON",
Format_Version: "104",
Format_Creator: "Elton Boehnen",
Records_Type: [recordsType],
Fields: fields,
Values: values
};
}

function create104a(recordsType, fields, values, customHeaders = {}) {
const doc = {
Format: "BEJSON",
Format_Version: "104a",
Format_Creator: "Elton Boehnen",
...customHeaders,
Records_Type: [recordsType],
Fields: fields,
Values: values
};
return doc;
}

function create104db(recordsTypes, fields, values) {
return {
Format: "BEJSON",
Format_Version: "104db",
Format_Creator: "Elton Boehnen",
Records_Type: recordsTypes,
Fields: fields,
Values: values
};
}

// ---------------------------------------------------------------------------
// Loading & Parsing
// ---------------------------------------------------------------------------
function loadFile(filePath) {
if (!fs.existsSync(filePath)) throw new BEJSONCoreError(`File not found: ${filePath}`, E_CORE_FIELD_NOT_FOUND);
validator.validateFile(filePath);
return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

function loadString(jsonString) {
validator.validateString(jsonString);
return JSON.parse(jsonString);
}

// ---------------------------------------------------------------------------
// Getters & Indexing
// ---------------------------------------------------------------------------
function getVersion(doc) { return doc.Format_Version; }
function getRecordsTypes(doc) { return doc.Records_Type; }
function getFields(doc) { return doc.Fields; }
function getFieldCount(doc) { return doc.Fields.length; }
function getRecordCount(doc) { return doc.Values.length; }

function getFieldIndex(doc, fieldName) {
const idx = doc.Fields.findIndex(f => f.name === fieldName);
if (idx === -1) throw new BEJSONCoreError(`Field not found: ${fieldName}`, E_CORE_FIELD_NOT_FOUND);
return idx;
}

function getFieldDef(doc, fieldName) {
const idx = getFieldIndex(doc, fieldName);
return doc.Fields[idx];
}

function _checkBounds(doc, rIdx, fIdx = 0) {
if (rIdx < 0 || rIdx >= doc.Values.length) throw new BEJSONCoreError(`Record index ${rIdx} out of bounds`, E_CORE_INDEX_OUT_OF_BOUNDS);
if (fIdx < 0 || fIdx >= doc.Fields.length) throw new BEJSONCoreError(`Field index ${fIdx} out of bounds`, E_CORE_INDEX_OUT_OF_BOUNDS);
}

function getValueAt(doc, recordIndex, fieldIndex) {
_checkBounds(doc, recordIndex, fieldIndex);
return doc.Values[recordIndex][fieldIndex];
}

function getRecord(doc, recordIndex) {
_checkBounds(doc, recordIndex, 0);
return doc.Values[recordIndex];
}

function getFieldValues(doc, fieldName) {
const idx = getFieldIndex(doc, fieldName);
return doc.Values.map(r => r[idx]);
}

// ---------------------------------------------------------------------------
// Querying
// ---------------------------------------------------------------------------
function queryRecords(doc, fieldName, searchValue) {
const idx = getFieldIndex(doc, fieldName);
return doc.Values.filter(r => r[idx] === searchValue);
}

function queryRecordsAdvanced(doc, conditions) {
const indices = {};
for (const key of Object.keys(conditions)) {
indices[key] = getFieldIndex(doc, key);
}

```
return doc.Values.filter(r => {
    for (const [key, searchVal] of Object.entries(conditions)) {
        if (r[indices[key]] !== searchVal) return false;
    }
    return true;
});

```

}

function getRecordsByType(doc, recordType) {
if (getVersion(doc) !== "104db") throw new BEJSONCoreError("Operation requires 104db document", E_CORE_INVALID_OPERATION);
return doc.Values.filter(r => r[0] === recordType);
}

function hasRecordType(doc, recordType) {
return doc.Records_Type.includes(recordType);
}

function getFieldApplicability(doc, fieldName) {
const def = getFieldDef(doc, fieldName);
return def.Record_Type_Parent || "common";
}

// ---------------------------------------------------------------------------
// Data Modification (Immutable style - returns new objects)
// ---------------------------------------------------------------------------
function _coerceValue(value, fieldType) {
if (value === null) return null;
if (fieldType === "string") return String(value);
if (fieldType === "integer") {
const parsed = parseInt(value, 10);
if (isNaN(parsed)) throw new BEJSONCoreError(`Cannot convert to integer`, E_CORE_TYPE_CONVERSION_FAILED);
return parsed;
}
if (fieldType === "number") {
const parsed = parseFloat(value);
if (isNaN(parsed)) throw new BEJSONCoreError(`Cannot convert to number`, E_CORE_TYPE_CONVERSION_FAILED);
return parsed;
}
if (fieldType === "boolean") {
if (typeof value === "boolean") return value;
if (typeof value === "string") {
const low = value.toLowerCase();
if (low === "true") return true;
if (low === "false") return false;
}
throw new BEJSONCoreError(`Cannot convert to boolean`, E_CORE_TYPE_CONVERSION_FAILED);
}
return value;
}

function setValueAt(doc, recordIndex, fieldIndex, newValue) {
_checkBounds(doc, recordIndex, fieldIndex);
const fType = doc.Fields[fieldIndex].type;
const coerced = _coerceValue(newValue, fType);

```
const newDoc = _clone(doc);
newDoc.Values[recordIndex][fieldIndex] = coerced;
return newDoc;

```

}

function addRecord(doc, values) {
if (values.length !== doc.Fields.length) {
throw new BEJSONCoreError(`Record must have ${doc.Fields.length} values, got ${values.length}`, E_CORE_INVALID_OPERATION);
}
const coerced = values.map((v, i) => _coerceValue(v, doc.Fields[i].type));
const newDoc = _clone(doc);
newDoc.Values.push(coerced);
return newDoc;
}

function removeRecord(doc, recordIndex) {
_checkBounds(doc, recordIndex, 0);
const newDoc = _clone(doc);
newDoc.Values.splice(recordIndex, 1);
return newDoc;
}

function updateField(doc, recordIndex, fieldName, newValue) {
const fIdx = getFieldIndex(doc, fieldName);
return setValueAt(doc, recordIndex, fIdx, newValue);
}

// ---------------------------------------------------------------------------
// Table Operations
// ---------------------------------------------------------------------------
function addColumn(doc, fieldName, fieldType, defaultValue = null, recordTypeParent = "") {
try {
getFieldIndex(doc, fieldName);
throw new BEJSONCoreError(`Field '${fieldName}' already exists`, E_CORE_INVALID_OPERATION);
} catch (e) {
if (e.code !== E_CORE_FIELD_NOT_FOUND) throw e;
}

```
const newField = { name: fieldName, type: fieldType };
if (recordTypeParent) newField.Record_Type_Parent = recordTypeParent;

const newDoc = _clone(doc);
newDoc.Fields.push(newField);
newDoc.Values.forEach(r => r.push(defaultValue));
return newDoc;

```

}

function removeColumn(doc, fieldName) {
const idx = getFieldIndex(doc, fieldName);
const newDoc = _clone(doc);
newDoc.Fields.splice(idx, 1);
newDoc.Values.forEach(r => r.splice(idx, 1));
return newDoc;
}

function renameColumn(doc, oldName, newName) {
const idx = getFieldIndex(doc, oldName);
try {
getFieldIndex(doc, newName);
throw new BEJSONCoreError(`Field '${newName}' already exists`, E_CORE_INVALID_OPERATION);
} catch (e) {
if (e.code !== E_CORE_FIELD_NOT_FOUND) throw e;
}

```
const newDoc = _clone(doc);
newDoc.Fields[idx].name = newName;
return newDoc;

```

}

function getColumn(doc, fieldName) {
return getFieldValues(doc, fieldName);
}

function setColumn(doc, fieldName, valuesArray) {
const idx = getFieldIndex(doc, fieldName);
if (valuesArray.length !== doc.Values.length) {
throw new BEJSONCoreError(`Value count must match record count`, E_CORE_INVALID_OPERATION);
}
const newDoc = _clone(doc);
for (let i = 0; i < valuesArray.length; i++) {
newDoc.Values[i][idx] = valuesArray[i];
}
return newDoc;
}

function filterRows(doc, predicateFn) {
const newDoc = _clone(doc);
newDoc.Values = newDoc.Values.filter(r => predicateFn(r));
return newDoc;
}

function sortByField(doc, fieldName, ascending = true) {
const idx = getFieldIndex(doc, fieldName);
const newDoc = _clone(doc);

```
newDoc.Values.sort((a, b) => {
    const valA = a[idx];
    const valB = b[idx];
    
    if (valA === null && valB === null) return 0;
    if (valA === null) return ascending ? -1 : 1;
    if (valB === null) return ascending ? 1 : -1;
    
    if (valA < valB) return ascending ? -1 : 1;
    if (valA > valB) return ascending ? 1 : -1;
    return 0;
});

return newDoc;

```

}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------
function prettyPrint(doc) {
return JSON.stringify(doc, null, 2);
}

function compactPrint(doc) {
return JSON.stringify(doc);
}

function isValid(doc) {
try {
validator.validateString(JSON.stringify(doc));
return true;
} catch (e) {
return false;
}
}

function getStats(doc) {
return {
version: getVersion(doc),
field_count: getFieldCount(doc),
record_count: getRecordCount(doc),
records_types: getRecordsTypes(doc)
};
}

module.exports = {
BEJSONCoreError,
ERRORS: {
E_CORE_INVALID_VERSION, E_CORE_INVALID_OPERATION, E_CORE_INDEX_OUT_OF_BOUNDS,
E_CORE_FIELD_NOT_FOUND, E_CORE_TYPE_CONVERSION_FAILED, E_CORE_BACKUP_FAILED,
E_CORE_WRITE_FAILED, E_CORE_QUERY_FAILED
},
atomicWrite,
create104,
create104a,
create104db,
loadFile,
loadString,
getVersion,
getRecordsTypes,
getFields,
getFieldIndex,
getFieldDef,
getFieldCount,
getRecordCount,
getValueAt,
getRecord,
getFieldValues,
queryRecords,
queryRecordsAdvanced,
getRecordsByType,
hasRecordType,
getFieldApplicability,
setValueAt,
addRecord,
removeRecord,
updateField,
addColumn,
removeColumn,
renameColumn,
getColumn,
setColumn,
filterRows,
sortByField,
prettyPrint,
compactPrint,
isValid,
getStats
};