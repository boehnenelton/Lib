"""
Library:     lib_html2_page_templates.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.3 (OFFICIAL)
Date:        2026-04-24
Description: Full HTML Dashboard templates for BEJSON data.
             Unified Dashboard Architecture v4.2.
             Added: Deep Categorization support & download linking.
"""
import html as html_mod
import os
import json
import re
from datetime import datetime

# Import skeletons
from lib_bejson_html2_skeletons import (
    COLOR, CSS_CORE, HTML_SKELETON
)

# ═══════════════════════════════════════════════════════
# 1. CORE PAGE GENERATION
# ═══════════════════════════════════════════════════════

def html_page(title, content, nav_links=None, status_extra="", active_url=""):
    """
    Generate a full Core-Command Dashboard page.
    :param title: Page Title
    :param content: Inner HTML content for the main area
    :param nav_links: List of {"category": "...", "items": [{"label": "...", "url": "..."}]}
    :param status_extra: Extra text for the status footer
    """
    
    # 1. CSS Injection
    css = CSS_CORE.format(**COLOR)
    
    # 2. Sidebar Tree-view Generation
    nav_html = ""
    if nav_links:
        for cat in nav_links:
            cat_name = cat.get("category", "General")
            nav_html += f'<li class="sidebar__category">{html_mod.escape(cat_name)} <span class="cat-arrow">▶</span></li>\n'
            nav_html += '<ul class="sidebar__category-items">\n'
            for item in cat.get("items", []):
                label = html_mod.escape(item.get("label", "Link"))
                url = item.get("url", "#")
                # Handle relative pathing for active state check
                active_class = " sidebar__link--active" if url == active_url or url.endswith("/" + active_url) else ""
                nav_html += f'  <li><a href="{url}" class="sidebar__link{active_class}">> {label}</a></li>\n'
            nav_html += '</ul>\n'
    else:
        nav_html = '<li class="sidebar__category">Navigation <span class="cat-arrow">▶</span></li>'
        nav_html += '<ul class="sidebar__category-items"><li><a href="#" class="sidebar__link">> No Links</a></li></ul>'

    # 3. Final Assembly
    return HTML_SKELETON.replace("{{title}}", html_mod.escape(title)) \
                       .replace("{{css}}", css) \
                       .replace("{{nav_items}}", nav_html) \
                       .replace("{{content}}", content) \
                       .replace("{{status_extra}}", html_mod.escape(status_extra))

def html_dashboard(title, bejson_doc, nav_links=None):
    """
    Convenience function: Builds a dashboard around a BEJSON Table.
    """
    from lib_html2_tables import html_table
    table_content = html_table(bejson_doc)
    
    # Add a header for the content area
    content = f'<h1 style="margin-bottom:24px;">{html_mod.escape(title)}</h1>'
    content += table_content
    
    return html_page(title, content, nav_links=nav_links, status_extra=f"DATA: {bejson_doc.get('Format_Version', 'UNK')}")

def html_save(content, path):
    """Unified save function for generated HTML."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

# ═══════════════════════════════════════════════════════
# 2. STATIC WIKI ENGINE
# ═══════════════════════════════════════════════════════

class BEJSONWiki:
    def __init__(self, title="System Wiki", output_dir=None, root_dir=None):
        self.title = title
        self.output_dir = output_dir # Where pages go (e.g. lib/DOCS_WIKI)
        self.root_dir = root_dir     # Where index goes (e.g. lib/)
        self.pages = [] # List of {name, url, category, tags, source_rel_path}

    def _extract_tags(self, first_line):
        if not first_line: return []
        return re.findall(r'#(\w+)', first_line)

    def _simple_md_to_html(self, text):
        lines = text.split('\n')
        html_lines = []
        in_code = False
        for line in lines:
            if line.strip().startswith('```'):
                if not in_code:
                    html_lines.append('<pre class="code-block"><code>')
                    in_code = True
                else:
                    html_lines.append('</code></pre>')
                    in_code = False
                continue
            if in_code:
                html_lines.append(html_mod.escape(line))
                continue
            if line.startswith('### '): html_lines.append(f'<h3>{line[4:]}</h3>')
            elif line.startswith('## '): html_lines.append(f'<h2>{line[3:]}</h2>')
            elif line.startswith('# '): html_lines.append(f'<h1>{line[2:]}</h1>')
            elif line.startswith('- '): html_lines.append(f'<li>{line[2:]}</li>')
            else:
                line = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', line)
                html_lines.append(f'<p>{line}</p>')
        return '\n'.join(html_lines)

    def render_all(self):
        # Build Navigation Tree
        nav_tree = {}
        for p in self.pages:
            cat = p.get('category', 'General')
            if cat not in nav_tree: nav_tree[cat] = []
            
            # Paths relative to the PAGE being rendered
            # All category pages are in self.output_dir/CATEGORY/
            nav_tree[cat].append({
                "label": p['name'], 
                "url": f"../{cat}/{p['url']}" if p['url'] != "index.html" else "../../library_docs.html"
            })
            
        nav_links = []
        nav_links.append({"category": "Home", "items": [{"label": "Index", "url": "../../library_docs.html"}]})
        for cat, items in nav_tree.items():
            nav_links.append({"category": cat, "items": items})
            
        for p in self.pages:
            cat = p.get('category', 'General')
            tag_html = "".join([f'<span class="badge" style="margin-right:5px;background:#333;">{t}</span>' for t in p['tags']])
            
            # Action Bar for Download/Source
            action_bar = f"""
            <div style="margin: 20px 0; display: flex; gap: 10px;">
                <a href="../../{p['source_rel_path']}" class="form__button" download>DOWNLOAD SOURCE</a>
                <a href="../../{p['source_rel_path']}" class="form__button--outline" target="_blank">VIEW RAW</a>
            </div>
            """
            
            full_content = f'<div style="margin-bottom:20px;">{tag_html}</div>{action_bar}{p["content"]}'
            
            final_html = html_page(
                title=f"{self.title} | {p['name']}",
                content=full_content,
                nav_links=nav_links,
                status_extra=f"WIKI | {cat}",
                active_url=f"../{cat}/{p['url']}"
            )
            
            page_path = os.path.join(self.output_dir, cat, p['url'])
            html_save(final_html, page_path)

        self._build_index(nav_tree)

    def _build_index(self, nav_tree):
        # Index is in self.root_dir (lib/)
        # nav_links for index need to point into DOCS_WIKI/CAT/
        index_nav = []
        index_nav.append({"category": "Home", "items": [{"label": "Index", "url": "library_docs.html"}]})
        for cat, items in nav_tree.items():
            cat_items = []
            for item in items:
                cat_items.append({"label": item['label'], "url": f"DOCS_WIKI/{cat}/{os.path.basename(item['url'])}"})
            index_nav.append({"category": cat, "items": cat_items})

        content = f'<div class="page-header"><h1>{self.title}</h1><p>System Knowledge Hub & Library Archive</p></div>'
        
        # Download All Zip (Placeholder link - user requested)
        content += """
        <div class="glass-stats" style="margin-bottom:30px;">
            <div class="glass-stats__item">
                <span class="glass-stats__label">PACKAGE</span>
                <span class="glass-stats__value">BEJSON_FULL_v1.1.zip</span>
            </div>
            <div style="margin-left:auto; display:flex; align-items:center;">
                <a href="retain.zip" class="form__button" download>DOWNLOAD ALL LIBRARIES (.ZIP)</a>
            </div>
        </div>
        """
        
        content += '<div class="card-grid">'
        for cat, items in nav_tree.items():
            content += f"""
            <div class="card">
                <h2 style="color:var(--primary-red); border-bottom:1px solid #222; padding-bottom:8px; margin-bottom:15px;">{cat}</h2>
                <ul style="list-style:none;">"""
            for item in items:
                link = f"DOCS_WIKI/{cat}/{os.path.basename(item['url'])}"
                content += f'<li style="margin-bottom:8px;"><a href="{link}">> {item["label"]}</a></li>'
            content += '</ul></div>'
        content += '</div>'

        final_index = html_page(
            title=self.title,
            content=content,
            nav_links=index_nav,
            status_extra="MASTER INDEX",
            active_url="library_docs.html"
        )
        # Save index to the library root as library_docs.html
        html_save(final_index, os.path.join(self.root_dir, "library_docs.html"))
