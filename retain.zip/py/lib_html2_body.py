"""
Library:     lib_html2_body.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.1 (OFFICIAL)
Date:        2026-04-23
Description: Content components for Unified Dashboard v4.0.
             Implements Glass Stats, BEM Cards, and Status Badges.
"""
import html as html_mod

def html_stats_bar(stats_list):
    """
    Generate a glass stats bar.
    :param stats_list: List of {"label": "...", "value": "..."}
    """
    if not stats_list: return ""
    items = ""
    for s in stats_list:
        label = html_mod.escape(str(s.get("label", "")))
        value = html_mod.escape(str(s.get("value", "")))
        items += f"""
        <div class="glass-stats__item">
            <span class="glass-stats__label">{label}</span>
            <span class="glass-stats__value">{value}</span>
        </div>"""
    return f'<div class="glass-stats">{items}</div>'

def html_subtabs(tabs):
    """
    Generate horizontal sub-navigation tabs for the dashboard body.
    :param tabs: List of dicts with {"label": "...", "id": "...", "active": bool}
    """
    if not tabs: return ""
    items = ""
    for t in tabs:
        active_class = " subtabs__btn--active" if t.get("active") else ""
        label = html_mod.escape(str(t.get("label", "")))
        tab_id = html_mod.escape(str(t.get("id", "")))
        items += f'<button class="subtabs__btn{active_class}" onclick="switchSubTab(\'{tab_id}\')">{label}</button>\n'
    return f'<div class="subtabs">{items}</div>'

def html_tab_content(tab_id, content, active=False):
    """Wraps content in a tab pane."""
    style = "display: block;" if active else "display: none;"
    return f'<div id="{html_mod.escape(tab_id)}" class="tab-content" style="{style}">{content}</div>'

def html_card(title, body):
    """Generate a dashboard card."""
    return f"""
    <div class="card">
        <h2 class="card__title">{html_mod.escape(title)}</h2>
        <p>{body}</p>
    </div>"""

def html_card_grid(cards_html):
    """Wraps cards in a grid."""
    return f'<div class="card-grid">{cards_html}</div>'

def html_badge(text, variant=""):
    """
    Generate a status badge.
    Variant can be 'success', 'fail', or empty for neutral.
    """
    style = ""
    if variant == "success": style = "color:#00FF00;"
    elif variant == "fail": style = "color:#FF0000;"
    return f'<span class="badge" style="font-family:var(--font-mono);font-weight:bold;{style}">[{html_mod.escape(text.upper())}]</span>'
