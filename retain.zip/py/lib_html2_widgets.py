"""
Library:     lib_html2_widgets.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.1 (OFFICIAL)
Date:        2026-04-23
Description: UI widgets and plugins for BEJSON HTML generation.
             Refactored to follow Modular CSS Policy (centralized in skeletons).
"""
import html as html_mod
import os
import json
import re
from pathlib import Path

def html_gallery(dir_path, recursive=False, container_id=None):
    """Generate an image gallery widget using .gallery-grid BEM classes."""
    cid = container_id or f"gallery_{id(dir_path)}"
    path = Path(dir_path)
    if not path.exists(): return f"<div>Error: {dir_path} not found</div>"
    
    extensions = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')
    pattern = "**/*" if recursive else "*"
    items = ""
    for img in sorted(path.glob(pattern)):
        if img.suffix.lower() in extensions:
            items += f"""
            <div class="gallery-item">
                <a href="{img}" target="_blank">
                    <img src="{img}" alt="{img.name}" loading="lazy">
                </a>
                <div class="gallery-item__label">{img.name}</div>
            </div>"""
            
    return f'<div id="{cid}" class="gallery-grid">{items}</div>'

def html_video_grid(videos, container_id=None):
    """Generate a responsive grid of embedded videos using .video-grid BEM classes."""
    cid = container_id or f"vgrid_{id(videos)}"
    items = ""
    for vid in videos:
        url = vid.get('url', '')
        title = vid.get('title', 'Video')
        
        embed_url = url
        if "youtube.com/watch" in url:
            vid_id = re.search(r'v=([^&]+)', url)
            if vid_id: embed_url = f"https://www.youtube.com/embed/{vid_id.group(1)}"
        elif "youtu.be/" in url:
            vid_id = url.split("youtu.be/")[1]
            embed_url = f"https://www.youtube.com/embed/{vid_id}"

        items += f"""
        <div class="video-card">
            <div class="video-card__header">{html_mod.escape(title)}</div>
            <div class="video-card__embed">
                <iframe src="{embed_url}" allowfullscreen loading="lazy"></iframe>
            </div>
        </div>"""

    return f'<div id="{cid}" class="video-grid">{items}</div>'

def html_info_box(title, content, link_url=None, link_label="View More", container_id=None):
    """Generate a stylized info box using .info-box BEM classes."""
    cid = container_id or f"infobox_{id(title)}"
    link_html = f"""<a href="{link_url}" class="info-box__link">{link_label}</a>""" if link_url else ""
    
    return f"""
    <div id="{cid}" class="info-box">
        <h3 class="info-box__title">
            <span class="info-box__dot"></span>
            {html_mod.escape(title)}
        </h3>
        <div class="info-box__content">{content}</div>
        {link_html}
    </div>
    """

def html_standalone_widget(html_content, title="Widget", container_id=None):
    """Wraps standalone HTML into an isolated iframe."""
    cid = container_id or f"standalone_widget_{id(title)}"
    escaped_content = html_mod.escape(html_content, quote=True)
    
    return f"""
    <div id="{cid}" class="standalone-widget-container" style="width: 100%; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; background: #000;">
        <div class="widget-header" style="background: #111; padding: 10px 15px; border-bottom: 1px solid var(--border-color); font-family: var(--font-family-mono); font-size: 12px; color: var(--text-color); display: flex; justify-content: space-between; align-items: center;">
            <span style="color: var(--primary-color); font-weight: bold;">{html_mod.escape(title)}</span>
            <span style="color: #666;">Isolated Component</span>
        </div>
        <iframe srcdoc="{escaped_content}" style="width: 100%; height: 600px; border: none; display: block;" sandbox="allow-scripts allow-same-origin"></iframe>
    </div>
    """

def html_load_widget(widget_name, components_dir=None, container_id=None):
    """Loads an external HTML component."""
    if not components_dir:
        components_dir = os.environ.get("CC_COMPONENTS", "/storage/7B30-0E0B/Core-Command/Templates/Components")
    
    path = Path(components_dir) / f"{widget_name}.html"
    if not path.exists():
        return f"<div>Error: Widget component '{widget_name}' not found in {components_dir}</div>"
        
    try:
        content = path.read_text(encoding='utf-8')
        return html_standalone_widget(content, title=widget_name, container_id=container_id)
    except Exception as e:
        return f"<div>Error loading widget '{widget_name}': {e}</div>"
