"""
Library:     lib_mfdb_core.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.1 (OFFICIAL) CoreEvo fork
Date:        2026-04-23
Description: MFDB (Multifile Database) core operations.
             Layers on lib_bejson_core.py and lib_mfdb_validator.py.
             Provides create, read, write, query, join, and sync
             operations across MFDB entity files and their manifest.
             DECOUPLED from BEJSON core — imports core (unidirectional).
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from lib_bejson_core import (
    BEJSONCoreError,
    bejson_core_atomic_write,
    bejson_core_add_record,
    bejson_core_remove_record,
    bejson_core_update_field,
    bejson_core_load_file,
    bejson_core_get_record_count,
    bejson_core_filter_rows,
    bejson_core_sort_by_field,
    bejson_core_get_field_index,
)
from lib_mfdb_validator import (
    MFDBValidationError,
    mfdb_validator_validate_manifest,
    mfdb_validator_validate_entity_file,
    _load_json,
    _rows_as_dicts,
    _resolve_entity_path,
)

# ---------------------------------------------------------------------------
# Error codes (50–69)
# ---------------------------------------------------------------------------

E_MFDB_CORE_MANIFEST_NOT_FOUND  = 50
E_MFDB_CORE_ENTITY_NOT_FOUND    = 51
E_MFDB_CORE_WRITE_FAILED        = 52
E_MFDB_CORE_CREATE_FAILED       = 53
E_MFDB_CORE_INVALID_OPERATION   = 54
E_MFDB_CORE_INDEX_OUT_OF_BOUNDS = 55
E_MFDB_CORE_JOIN_FAILED         = 56


class MFDBCoreError(Exception):
    """Raised when an MFDB core operation fails."""
    def __init__(self, message: str, code: int):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_manifest_entries(manifest_path: str) -> list[dict]:
    doc = _load_json(manifest_path)
    return _rows_as_dicts(doc)


def _get_manifest_entry(manifest_path: str, entity_name: str) -> dict:
    entries = _get_manifest_entries(manifest_path)
    entry   = next((e for e in entries if e.get("entity_name") == entity_name), None)
    if entry is None:
        raise MFDBCoreError(
            f"Entity '{entity_name}' not found in manifest: {manifest_path}",
            E_MFDB_CORE_ENTITY_NOT_FOUND,
        )
    return entry


def _get_entity_path(manifest_path: str, entity_name: str) -> str:
    entry = _get_manifest_entry(manifest_path, entity_name)
    return _resolve_entity_path(manifest_path, entry["file_path"])


def _load_entity_doc(manifest_path: str, entity_name: str) -> dict:
    """Load and validate the raw BEJSON 104 doc for an entity."""
    entity_path = _get_entity_path(manifest_path, entity_name)
    return bejson_core_load_file(entity_path)


def _write_entity_doc(doc: dict, entity_path: str) -> None:
    bejson_core_atomic_write(entity_path, doc)


def _write_manifest_doc(doc: dict, manifest_path: str) -> None:
    bejson_core_atomic_write(manifest_path, doc)


def _update_manifest_record_count(
    manifest_path: str, entity_name: str, count: int
) -> None:
    """Write a corrected record_count into the manifest for one entity.
    No-op if the manifest does not have a record_count field."""
    doc        = _load_json(manifest_path)
    fn_list    = [f["name"] for f in doc["Fields"]]
    if "record_count" not in fn_list or "entity_name" not in fn_list:
        return
    rc_idx = fn_list.index("record_count")
    en_idx = fn_list.index("entity_name")
    for row in doc["Values"]:
        if row[en_idx] == entity_name:
            row[rc_idx] = count
            break
    _write_manifest_doc(doc, manifest_path)


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def mfdb_core_discover(file_path: str) -> str:
    """
    Identify the MFDB role of any BEJSON file.

    Returns one of:
        'manifest'   — BEJSON 104a file whose name ends in .mfdb.bejson
        'entity'     — BEJSON 104 file with a Parent_Hierarchy key
        'standalone' — any other valid BEJSON file

    Mirrors the discovery algorithm in the MFDB spec §9.1.
    Raises MFDBCoreError if the file does not exist.
    """
    p = Path(file_path)
    if not p.exists():
        raise MFDBCoreError(f"File not found: {file_path}", E_MFDB_CORE_MANIFEST_NOT_FOUND)

    try:
        doc = _load_json(file_path)
    except Exception:
        return "standalone"

    version  = doc.get("Format_Version", "")
    filename = p.name

    if version == "104a" and filename.endswith(".mfdb.bejson"):
        return "manifest"
    if version == "104" and doc.get("Parent_Hierarchy"):
        return "entity"
    return "standalone"


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------

def mfdb_core_load_manifest(manifest_path: str) -> list[dict]:
    """
    Validate and load the manifest.
    Returns all manifest records as a list of field-name-keyed dicts.
    """
    mfdb_validator_validate_manifest(manifest_path)
    return _get_manifest_entries(manifest_path)


def mfdb_core_load_entity(manifest_path: str, entity_name: str) -> list[dict]:
    """
    Load all records for a named entity.
    Returns a list of field-name-keyed dicts (dense — no null-padding).
    """
    doc = _load_entity_doc(manifest_path, entity_name)
    return _rows_as_dicts(doc)


def mfdb_core_get_entity_doc(manifest_path: str, entity_name: str) -> dict:
    """Return the raw BEJSON 104 document dict for a named entity."""
    return _load_entity_doc(manifest_path, entity_name)


def mfdb_core_get_stats(manifest_path: str) -> dict:
    """
    Return a summary statistics dict for the entire MFDB.

    Structure::

        {
          "db_name":      str,
          "schema_version": str,
          "entity_count": int,
          "entities": [
            {
              "entity_name": str,
              "file_path":   str,
              "record_count": int,   # actual rows in file (-1 if file missing)
              "field_count":  int,
              "primary_key":  str | None,
            },
            ...
          ]
        }
    """
    doc     = _load_json(manifest_path)
    entries = _rows_as_dicts(doc)

    entity_stats = []
    for entry in entries:
        resolved = _resolve_entity_path(manifest_path, entry["file_path"])
        if os.path.exists(resolved):
            edoc        = _load_json(resolved)
            rec_count   = len(edoc.get("Values", []))
            field_count = len(edoc.get("Fields", []))
        else:
            rec_count   = -1
            field_count = -1

        entity_stats.append({
            "entity_name":  entry["entity_name"],
            "file_path":    entry["file_path"],
            "record_count": rec_count,
            "field_count":  field_count,
            "primary_key":  entry.get("primary_key"),
        })

    return {
        "db_name":        doc.get("DB_Name", ""),
        "schema_version": doc.get("Schema_Version", ""),
        "entity_count":   len(entries),
        "entities":       entity_stats,
    }


# ---------------------------------------------------------------------------
# Query operations
# ---------------------------------------------------------------------------

def mfdb_core_query_entity(
    manifest_path: str,
    entity_name: str,
    predicate: Callable[[dict], bool],
) -> list[dict]:
    """
    Return all records from an entity for which predicate(record) is True.
    predicate receives a field-name-keyed dict (not a raw list).
    """
    records = mfdb_core_load_entity(manifest_path, entity_name)
    return [r for r in records if predicate(r)]


def mfdb_core_build_index(
    manifest_path: str,
    entity_name: str,
    field_name: str,
) -> dict:
    """
    Build an in-memory hash index on a field for fast lookups.

    Returns {field_value: record_dict}.
    Useful for FK resolution and JOIN acceleration.
    Implements the 'hash' index type from the MFDB spec §4 Indexes proposal.
    """
    records = mfdb_core_load_entity(manifest_path, entity_name)
    return {r[field_name]: r for r in records if r.get(field_name) is not None}


def mfdb_core_join(
    manifest_path: str,
    from_entity:   str,
    to_entity:     str,
    from_fk:       str,
    to_pk:         str,
) -> list[dict]:
    """
    Cross-entity equi-join.

    For each record in from_entity, looks up the matching record in to_entity
    where to_entity[to_pk] == from_entity[from_fk].

    Fields from the right-hand side (to_entity) are prefixed with
    '<to_entity>__' to prevent name collisions. Unmatched FK values produce
    a record whose <to_entity>__ fields are all absent (left outer join
    behaviour).

    Returns a list of merged dicts.
    """
    from_records = mfdb_core_load_entity(manifest_path, from_entity)
    to_index     = mfdb_core_build_index(manifest_path, to_entity, to_pk)

    results = []
    for record in from_records:
        fk_val = record.get(from_fk)
        target = to_index.get(fk_val, {})
        merged = dict(record)
        for k, v in target.items():
            merged[f"{to_entity}__{k}"] = v
        results.append(merged)

    return results


# ---------------------------------------------------------------------------
# Write operations
# ---------------------------------------------------------------------------

def mfdb_core_add_entity_record(
    manifest_path: str,
    entity_name:   str,
    values:        list,
    sync_count:    bool = True,
) -> dict:
    """
    Append a record to an entity file.

    values must be a flat list matching the entity's field count and order.
    Type coercion is handled by lib_bejson_core.bejson_core_add_record.

    When sync_count=True (default), the manifest's record_count for this
    entity is updated atomically after the entity file write succeeds.
    Only the entity file and the manifest are touched — all other entity
    files remain untouched.

    Returns the updated entity document dict.
    """
    entity_path = _get_entity_path(manifest_path, entity_name)
    doc         = bejson_core_load_file(entity_path)
    doc         = bejson_core_add_record(doc, values)
    _write_entity_doc(doc, entity_path)
    if sync_count:
        _update_manifest_record_count(manifest_path, entity_name, len(doc["Values"]))
    return doc


def mfdb_core_remove_entity_record(
    manifest_path: str,
    entity_name:   str,
    record_index:  int,
    sync_count:    bool = True,
) -> dict:
    """
    Remove a record at record_index from an entity file.
    Returns the updated entity document dict.
    """
    entity_path = _get_entity_path(manifest_path, entity_name)
    doc         = bejson_core_load_file(entity_path)
    doc         = bejson_core_remove_record(doc, record_index)
    _write_entity_doc(doc, entity_path)
    if sync_count:
        _update_manifest_record_count(manifest_path, entity_name, len(doc["Values"]))
    return doc


def mfdb_core_update_entity_record(
    manifest_path: str,
    entity_name:   str,
    record_index:  int,
    field_name:    str,
    new_value:     Any,
) -> dict:
    """
    Update a single named field in a specific record of an entity file.
    Returns the updated entity document dict.
    """
    entity_path = _get_entity_path(manifest_path, entity_name)
    doc         = bejson_core_load_file(entity_path)
    doc         = bejson_core_update_field(doc, record_index, field_name, new_value)
    _write_entity_doc(doc, entity_path)
    return doc


# ---------------------------------------------------------------------------
# Manifest sync
# ---------------------------------------------------------------------------

def mfdb_core_sync_manifest_count(manifest_path: str, entity_name: str) -> int:
    """
    Re-count actual rows in an entity file and update the manifest.
    Returns the actual row count.
    """
    entity_path = _get_entity_path(manifest_path, entity_name)
    edoc        = _load_json(entity_path)
    count       = len(edoc.get("Values", []))
    _update_manifest_record_count(manifest_path, entity_name, count)
    return count


def mfdb_core_sync_all_counts(manifest_path: str) -> dict:
    """
    Sync record_count for every entity listed in the manifest.
    Returns {entity_name: actual_count}.
    """
    entries = _get_manifest_entries(manifest_path)
    results = {}
    for entry in entries:
        name = entry["entity_name"]
        results[name] = mfdb_core_sync_manifest_count(manifest_path, name)
    return results


# ---------------------------------------------------------------------------
# Database creation
# ---------------------------------------------------------------------------

def mfdb_core_create_entity_file(
    manifest_path:  str,
    entity_name:    str,
    fields:         list[dict],
    description:    str = "",
    primary_key:    str = "",
    schema_version: str = "1.0",
    file_path_rel:  str = "",
) -> str:
    """
    Create a new entity file and register it in an existing manifest.

    file_path_rel — relative path from the manifest directory to the new
    entity file. Defaults to 'data/<entity_name_lower>.bejson'.

    Returns the absolute path to the created entity file.
    """
    manifest_dir = os.path.dirname(os.path.abspath(manifest_path))

    if not file_path_rel:
        file_path_rel = f"data/{entity_name.lower()}.bejson"

    resolved = os.path.normpath(os.path.join(manifest_dir, file_path_rel))
    os.makedirs(os.path.dirname(resolved), exist_ok=True)

    # Compute Parent_Hierarchy: relative path from entity file back to manifest.
    entity_dir         = os.path.dirname(resolved)
    rel_to_manifest    = os.path.relpath(manifest_path, entity_dir)

    entity_doc = {
        "Format":           "BEJSON",
        "Format_Version":   "104",
        "Format_Creator":   "Elton Boehnen",
        "Parent_Hierarchy": rel_to_manifest,
        "Records_Type":     [entity_name],
        "Fields":           fields,
        "Values":           [],
    }
    bejson_core_atomic_write(resolved, entity_doc)

    # Append a record to the manifest for this new entity.
    manifest_doc = _load_json(manifest_path)
    fn_list      = [f["name"] for f in manifest_doc["Fields"]]

    new_row = []
    for fn in fn_list:
        if   fn == "entity_name":    new_row.append(entity_name)
        elif fn == "file_path":      new_row.append(file_path_rel)
        elif fn == "description":    new_row.append(description or None)
        elif fn == "record_count":   new_row.append(0)
        elif fn == "schema_version": new_row.append(schema_version)
        elif fn == "primary_key":    new_row.append(primary_key or None)
        else:                        new_row.append(None)

    manifest_doc["Values"].append(new_row)
    _write_manifest_doc(manifest_doc, manifest_path)

    return resolved


def mfdb_core_create_database(
    root_dir:       str,
    db_name:        str,
    entities:       list[dict],
    db_description: str = "",
    schema_version: str = "1.0.0",
    author:         str = "Elton Boehnen",
    mfdb_version:   str = "1.0",
) -> str:
    """
    Create a new MFDB from scratch.

    Creates the manifest (104a.mfdb.bejson) and all entity files under root_dir.

    Each entry in entities must be a dict with:
        name          (str, required)  — entity name, e.g. 'User'
        fields        (list, required) — BEJSON Fields array for the entity
        description   (str, optional)
        primary_key   (str, optional)  — field name of the PK, e.g. 'user_id'
        schema_version (str, optional, default '1.0')
        file_path     (str, optional, default 'data/<name_lower>.bejson')

    Returns the absolute path to the created manifest file.
    """
    root = Path(root_dir)
    root.mkdir(parents=True, exist_ok=True)
    manifest_path = str(root / "104a.mfdb.bejson")

    manifest_fields = [
        {"name": "entity_name",    "type": "string"},
        {"name": "file_path",      "type": "string"},
        {"name": "description",    "type": "string"},
        {"name": "record_count",   "type": "integer"},
        {"name": "schema_version", "type": "string"},
        {"name": "primary_key",    "type": "string"},
    ]

    manifest_values     = []
    entity_defs_to_file = []

    for entity in entities:
        name   = entity["name"]
        fp_rel = entity.get("file_path", f"data/{name.lower()}.bejson")
        desc   = entity.get("description", "")
        pk     = entity.get("primary_key", "")
        sv     = entity.get("schema_version", "1.0")
        fields = entity["fields"]

        manifest_values.append([name, fp_rel, desc or None, 0, sv, pk or None])
        entity_defs_to_file.append((name, fp_rel, fields))

    created_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    manifest_doc = {
        "Format":          "BEJSON",
        "Format_Version":  "104a",
        "Format_Creator":  "Elton Boehnen",
        "MFDB_Version":    mfdb_version,
        "DB_Name":         db_name,
        "DB_Description":  db_description,
        "Schema_Version":  schema_version,
        "Author":          author,
        "Created_At":      created_at,
        "Records_Type":    ["mfdb"],
        "Fields":          manifest_fields,
        "Values":          manifest_values,
    }

    bejson_core_atomic_write(manifest_path, manifest_doc)

    # Create each entity file with an empty Values array.
    for entity_name, fp_rel, fields in entity_defs_to_file:
        resolved   = os.path.normpath(os.path.join(root_dir, fp_rel))
        entity_dir = os.path.dirname(resolved)
        os.makedirs(entity_dir, exist_ok=True)

        rel_to_manifest = os.path.relpath(manifest_path, entity_dir)

        entity_doc = {
            "Format":           "BEJSON",
            "Format_Version":   "104",
            "Format_Creator":   "Elton Boehnen",
            "Parent_Hierarchy": rel_to_manifest,
            "Records_Type":     [entity_name],
            "Fields":           fields,
            "Values":           [],
        }
        bejson_core_atomic_write(resolved, entity_doc)

    return manifest_path
