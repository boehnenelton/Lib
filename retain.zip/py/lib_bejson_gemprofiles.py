"""
Library:     lib_bejson_gemprofiles.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.1 (OFFICIAL)
Date:        2026-04-23
Description: BEJSON-based AI Profile management library compatible with Profile Studio.
             Handles creation, mutation, and discovery of AI profiles (104).
"""
import os
import sys
import json
import time
from typing import Any, Optional

# Ensure local directory is in path for relative imports
LIB_DIR = os.path.dirname(os.path.abspath(__file__))
if LIB_DIR not in sys.path:
    sys.path.append(LIB_DIR)

from lib_bejson_core import (
    bejson_core_create_104,
    bejson_core_load_file,
    bejson_core_atomic_write,
    bejson_core_get_field_index,
    bejson_core_set_value_at,
    bejson_core_get_value_at,
    BEJSONCoreError
)

# ---------------------------------------------------------------------------
# SCHEMA DEFINITION (Profile Studio v104)
# ---------------------------------------------------------------------------

GEMPROFILE_FIELDS = [
    {"name": "Record_Type_Parent", "type": "string"},
    {"name": "Name", "type": "string"},
    {"name": "Archetype", "type": "string"},
    {"name": "Persona", "type": "string"},
    {"name": "SystemInstruction", "type": "string"},
    {"name": "ForbiddenTopics", "type": "array"},
    {"name": "Avatar_Type", "type": "string"},
    {"name": "Avatar_sourceUrl", "type": "string"},
    {"name": "Avatar_Data", "type": "string"},
    {"name": "MaxResponseTokens", "type": "integer"},
    {"name": "Creativity", "type": "number"},
    {"name": "Tone", "type": "array"},
    {"name": "Formality", "type": "string"},
    {"name": "Verbosity", "type": "string"},
    {"name": "EmotionalExpression_Enabled", "type": "boolean"},
    {"name": "EmotionalExpression_Intensity", "type": "number"},
    {"name": "GoogleSearch_Enabled", "type": "boolean"},
    {"name": "CodeInterpreter_Enabled", "type": "boolean"},
    {"name": "EphemeralMemory", "type": "boolean"},
    {"name": "CodeParsing_Mode", "type": "string"},
    {"name": "CodeParsing_Languages", "type": "array"},
    {"name": "CodeParsing_StructureValidation", "type": "boolean"},
    {"name": "CodeParsing_VersionControl", "type": "boolean"},
    {"name": "Thinking_Supported", "type": "boolean"}
]

# ---------------------------------------------------------------------------
# CORE API
# ---------------------------------------------------------------------------

def gemprofiles_create_default(name: str) -> dict:
    """Create a new AI Profile document with default values."""
    default_values = [
        "AI_Profile",                  # Record_Type_Parent
        name,                          # Name
        "Assistant",                   # Archetype
        "A helpful AI assistant.",     # Persona
        "You are a helpful assistant.",# SystemInstruction
        [],                            # ForbiddenTopics
        "Emoji",                       # Avatar_Type
        "",                            # Avatar_sourceUrl
        "🤖",                          # Avatar_Data
        2048,                          # MaxResponseTokens
        0.7,                           # Creativity
        ["Helpful", "Professional"],   # Tone
        "Neutral",                     # Formality
        "Normal",                      # Verbosity
        False,                         # EmotionalExpression_Enabled
        0.0,                           # EmotionalExpression_Intensity
        True,                          # GoogleSearch_Enabled
        False,                         # CodeInterpreter_Enabled
        True,                          # EphemeralMemory
        "complete",                    # CodeParsing_Mode
        ["python", "javascript"],      # CodeParsing_Languages
        True,                          # CodeParsing_StructureValidation
        False,                         # CodeParsing_VersionControl
        True                           # Thinking_Supported
    ]
    
    # 104 document creation (AI_Profile is the Records_Type entry)
    doc = bejson_core_create_104("AI_Profile", GEMPROFILE_FIELDS, [default_values])
    doc["Parent_Hierarchy"] = "/LLM_Configuration"
    return doc

def gemprofiles_load(file_path: str) -> dict:
    """Load an AI Profile from a .bejson file."""
    return bejson_core_load_file(file_path)

def gemprofiles_save(file_path: str, profile_doc: dict) -> None:
    """Atomically save an AI Profile to disk."""
    bejson_core_atomic_write(file_path, profile_doc)

def gemprofiles_update_field(profile_doc: dict, field_name: str, value: Any) -> dict:
    """Update a field in the first record of the profile document."""
    idx = bejson_core_get_field_index(profile_doc, field_name)
    return bejson_core_set_value_at(profile_doc, 0, idx, value)

def gemprofiles_get_field(profile_doc: dict, field_name: str) -> Any:
    """Get a field value from the first record of the profile document."""
    idx = bejson_core_get_field_index(profile_doc, field_name)
    return bejson_core_get_value_at(profile_doc, 0, idx)

def gemprofiles_list(profiles_dir: str) -> list[str]:
    """List names of all .bejson profiles in a directory."""
    if not os.path.isdir(profiles_dir):
        return []
    return [f for f in os.listdir(profiles_dir) if f.endswith(".bejson")]

# ---------------------------------------------------------------------------
# SPECIALIZED HELPERS
# ---------------------------------------------------------------------------

def gemprofiles_get_system_instruction(profile_doc: dict) -> str:
    """Retrieve the SystemInstruction field."""
    return gemprofiles_get_field(profile_doc, "SystemInstruction")

def gemprofiles_set_system_instruction(profile_doc: dict, instruction: str) -> dict:
    """Set the SystemInstruction field."""
    return gemprofiles_update_field(profile_doc, "SystemInstruction", instruction)

def gemprofiles_get_persona(profile_doc: dict) -> str:
    """Retrieve the Persona field."""
    return gemprofiles_get_field(profile_doc, "Persona")

def gemprofiles_set_persona(profile_doc: dict, persona: str) -> dict:
    """Set the Persona field."""
    return gemprofiles_update_field(profile_doc, "Persona", persona)
