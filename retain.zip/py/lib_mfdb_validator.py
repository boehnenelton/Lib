"""
Library:     lib_mfdb_validator.py
Jurisdiction: ["PYTHON", "CORE_COMMAND"]
Status:      OFFICIAL — Core-Command/Lib (v1.1)
Author:      Elton Boehnen
Version:     1.1 (OFFICIAL) CoreEvo fork
Date:        2026-04-23
Description: MFDB (Multifile Database) validation library.
             Layers entirely on lib_bejson_validator.py — no new BEJSON
             version, no new field types. All entity files remain valid
             standalone BEJSON 104 documents; the manifest is a valid
             BEJSON 104a document.
             DECOUPLED from BEJSON validator — imports validator (unidirectional).
"""
import json
import os
from dataclasses import dataclass, field as dc_field
from pathlib import Path

from lib_bejson_validator import (
    BEJSONValidationError,
    bejson_validator_validate_file,
)

# ---------------------------------------------------------------------------
# Error codes (30–49)
# ---------------------------------------------------------------------------

E_MFDB_NOT_MANIFEST           = 30
E_MFDB_NOT_ENTITY_FILE        = 31
E_MFDB_MANIFEST_RECORDS_TYPE  = 32
E_MFDB_ENTITY_NOT_FOUND       = 33
E_MFDB_ENTITY_NAME_MISMATCH   = 34
E_MFDB_DUPLICATE_ENTRY        = 35
E_MFDB_NO_PARENT_HIERARCHY    = 36
E_MFDB_MANIFEST_NOT_FOUND     = 37
E_MFDB_BIDIRECTIONAL_FAIL     = 38
E_MFDB_FK_UNRESOLVED          = 39
E_MFDB_MISSING_REQUIRED_FIELD = 40
E_MFDB_NULL_REQUIRED          = 41


class MFDBValidationError(Exception):
    """Raised when MFDB-level validation fails."""
    def __init__(self, message: str, code: int):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------------
# Validation state
# ---------------------------------------------------------------------------

@dataclass
class _MFDBValidationState:
    errors:   list[str] = dc_field(default_factory=list)
    warnings: list[str] = dc_field(default_factory=list)

    def reset(self):
        self.errors.clear()
        self.warnings.clear()

    def add_error(self, message: str, location: str = ""):
        entry = "ERROR"
        if location:
            entry += f" | Location: {location}"
        entry += f" | Message: {message}"
        self.errors.append(entry)

    def add_warning(self, message: str, location: str = ""):
        entry = "WARNING"
        if location:
            entry += f" | Location: {location}"
        entry += f" | Message: {message}"
        self.warnings.append(entry)

    def has_errors(self)   -> bool:     return bool(self.errors)
    def has_warnings(self) -> bool:     return bool(self.warnings)


_mstate = _MFDBValidationState()


# ---------------------------------------------------------------------------
# Internal helpers (also imported by lib_mfdb_core)
# ---------------------------------------------------------------------------

def _load_json(path: str) -> dict:
    """Load raw JSON without BEJSON validation (used internally)."""
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _rows_as_dicts(doc: dict) -> list[dict]:
    """Convert a BEJSON document's Values into a list of field-keyed dicts."""
    names = [f["name"] for f in doc["Fields"]]
    return [dict(zip(names, row)) for row in doc["Values"]]


def _resolve_entity_path(manifest_path: str, file_path_rel: str) -> str:
    """Resolve a relative file_path (from manifest record) to an absolute path."""
    manifest_dir = os.path.dirname(os.path.abspath(manifest_path))
    return os.path.normpath(os.path.join(manifest_dir, file_path_rel))


# ---------------------------------------------------------------------------
# Manifest Validation  (Spec §8.1)
# ---------------------------------------------------------------------------

def mfdb_validator_validate_manifest(manifest_path: str) -> bool:
    """
    Validate an MFDB manifest file (104a.mfdb.bejson).

    Checks performed:
      1. File exists.
      2. File is a valid BEJSON 104a document (delegates to lib_bejson_validator).
      3. Records_Type is exactly ["mfdb"].
      4. Fields include 'entity_name' and 'file_path'.
      5. No record has a null entity_name or file_path.
      6. entity_name values are unique across all records.
      7. file_path values are unique across all records.
      8. Every resolved file_path exists on disk.

    Raises MFDBValidationError on the first fatal failure.
    Returns True when all checks pass.
    """
    _mstate.reset()
    p = Path(manifest_path)

    if not p.exists():
        _mstate.add_error(f"Manifest file not found: {manifest_path}", "File System")
        raise MFDBValidationError(f"File not found: {manifest_path}", E_MFDB_MANIFEST_NOT_FOUND)

    # Delegate BEJSON 104a structural validation
    try:
        bejson_validator_validate_file(manifest_path)
    except BEJSONValidationError as exc:
        _mstate.add_error(f"BEJSON 104a validation failed: {exc}", "BEJSON Validation")
        raise MFDBValidationError(str(exc), E_MFDB_NOT_MANIFEST) from exc

    doc = _load_json(manifest_path)

    if doc.get("Format_Version") != "104a":
        _mstate.add_error("Manifest must be Format_Version '104a'", "Format_Version")
        raise MFDBValidationError("Manifest must be 104a", E_MFDB_NOT_MANIFEST)

    rt = doc.get("Records_Type", [])
    if rt != ["mfdb"]:
        _mstate.add_error(
            f'Records_Type must be ["mfdb"]. Found: {rt}',
            "Records_Type",
        )
        raise MFDBValidationError("Bad manifest Records_Type", E_MFDB_MANIFEST_RECORDS_TYPE)

    field_names = [f["name"] for f in doc.get("Fields", [])]
    for required in ("entity_name", "file_path"):
        if required not in field_names:
            _mstate.add_error(f"Manifest Fields must include '{required}'", "Fields")
            raise MFDBValidationError(
                f"Missing required field '{required}'", E_MFDB_MISSING_REQUIRED_FIELD
            )

    entries = _rows_as_dicts(doc)
    seen_names: set[str] = set()
    seen_paths: set[str] = set()

    for i, entry in enumerate(entries):
        entity_name = entry.get("entity_name")
        file_path   = entry.get("file_path")

        if not entity_name:
            _mstate.add_error(f"Record {i}: entity_name is null or missing", f"Values[{i}]")
            raise MFDBValidationError("Null entity_name", E_MFDB_NULL_REQUIRED)

        if not file_path:
            _mstate.add_error(f"Record {i}: file_path is null or missing", f"Values[{i}]")
            raise MFDBValidationError("Null file_path", E_MFDB_NULL_REQUIRED)

        if entity_name in seen_names:
            _mstate.add_error(f"Duplicate entity_name: '{entity_name}'", f"Values[{i}]")
            raise MFDBValidationError(f"Duplicate entity_name: {entity_name}", E_MFDB_DUPLICATE_ENTRY)
        seen_names.add(entity_name)

        if file_path in seen_paths:
            _mstate.add_error(f"Duplicate file_path: '{file_path}'", f"Values[{i}]")
            raise MFDBValidationError(f"Duplicate file_path: {file_path}", E_MFDB_DUPLICATE_ENTRY)
        seen_paths.add(file_path)

        resolved = _resolve_entity_path(manifest_path, file_path)
        if not os.path.exists(resolved):
            _mstate.add_error(
                f"Entity file '{file_path}' not found (resolved: {resolved})",
                f"Values[{i}]/file_path",
            )
            raise MFDBValidationError(f"Entity file not found: {resolved}", E_MFDB_ENTITY_NOT_FOUND)

    return True


# ---------------------------------------------------------------------------
# Entity File Validation  (Spec §8.2)
# ---------------------------------------------------------------------------

def mfdb_validator_validate_entity_file(
    entity_path: str,
    check_bidirectional: bool = True,
) -> bool:
    """
    Validate an MFDB entity file (BEJSON 104 with Parent_Hierarchy back-link).

    Checks performed:
      1. File exists.
      2. File is a valid BEJSON 104 document.
      3. Parent_Hierarchy key is present.
      4. Parent_Hierarchy resolves to an existing .mfdb.bejson file.
      5. Records_Type contains exactly one string.
      6. That single string appears as entity_name in the resolved manifest.
      7. Bidirectional check: the manifest's file_path for this entity resolves
         back to this file (pass check_bidirectional=False to skip during bulk
         DB validation where the manifest is already authoritative).

    Raises MFDBValidationError on the first fatal failure.
    Returns True when all checks pass.
    """
    _mstate.reset()
    p = Path(entity_path)

    if not p.exists():
        _mstate.add_error(f"Entity file not found: {entity_path}", "File System")
        raise MFDBValidationError(f"File not found: {entity_path}", E_MFDB_ENTITY_NOT_FOUND)

    try:
        bejson_validator_validate_file(entity_path)
    except BEJSONValidationError as exc:
        _mstate.add_error(f"BEJSON 104 validation failed: {exc}", "BEJSON Validation")
        raise MFDBValidationError(str(exc), E_MFDB_NOT_ENTITY_FILE) from exc

    doc = _load_json(entity_path)

    if doc.get("Format_Version") != "104":
        _mstate.add_error("Entity file must be Format_Version '104'", "Format_Version")
        raise MFDBValidationError("Entity file must be 104", E_MFDB_NOT_ENTITY_FILE)

    parent_hierarchy = doc.get("Parent_Hierarchy")
    if not parent_hierarchy:
        _mstate.add_error(
            "Entity file must contain Parent_Hierarchy pointing to the manifest",
            "Parent_Hierarchy",
        )
        raise MFDBValidationError("Missing Parent_Hierarchy", E_MFDB_NO_PARENT_HIERARCHY)

    entity_dir    = os.path.dirname(os.path.abspath(entity_path))
    manifest_path = os.path.normpath(os.path.join(entity_dir, parent_hierarchy))

    if not os.path.exists(manifest_path):
        _mstate.add_error(
            f"Parent_Hierarchy '{parent_hierarchy}' resolves to '{manifest_path}' which does not exist",
            "Parent_Hierarchy",
        )
        raise MFDBValidationError(f"Manifest not found: {manifest_path}", E_MFDB_MANIFEST_NOT_FOUND)

    if not os.path.basename(manifest_path).endswith(".mfdb.bejson"):
        _mstate.add_warning(
            f"Parent_Hierarchy target '{manifest_path}' does not end in '.mfdb.bejson'. "
            f"Expected filename: 104a.mfdb.bejson",
            "Parent_Hierarchy",
        )

    rt = doc.get("Records_Type", [])
    if len(rt) != 1:
        _mstate.add_error(
            f"Entity file Records_Type must contain exactly one string. Found: {rt}",
            "Records_Type",
        )
        raise MFDBValidationError("Entity Records_Type must be single-entry", E_MFDB_NOT_ENTITY_FILE)

    entity_name = rt[0]

    try:
        manifest_doc = _load_json(manifest_path)
        entries      = _rows_as_dicts(manifest_doc)
        manifest_entity_names = [e.get("entity_name") for e in entries]
    except Exception as exc:
        _mstate.add_error(f"Could not read manifest: {exc}", "Manifest")
        raise MFDBValidationError(f"Cannot read manifest: {exc}", E_MFDB_MANIFEST_NOT_FOUND) from exc

    if entity_name not in manifest_entity_names:
        _mstate.add_error(
            f"Records_Type '{entity_name}' does not appear as entity_name in the manifest",
            "Records_Type vs Manifest",
        )
        raise MFDBValidationError(
            f"Entity '{entity_name}' not registered in manifest", E_MFDB_ENTITY_NAME_MISMATCH
        )

    if check_bidirectional:
        match = next((e for e in entries if e.get("entity_name") == entity_name), None)
        if match:
            manifest_dir  = os.path.dirname(os.path.abspath(manifest_path))
            from_manifest = os.path.normpath(
                os.path.join(manifest_dir, match.get("file_path", ""))
            )
            this_file     = os.path.normpath(os.path.abspath(entity_path))
            if from_manifest != this_file:
                _mstate.add_error(
                    f"Bidirectional check failed for entity '{entity_name}': "
                    f"manifest points to '{from_manifest}', but this file is '{this_file}'",
                    "Bidirectional Path Check",
                )
                raise MFDBValidationError(
                    "Bidirectional path check failed", E_MFDB_BIDIRECTIONAL_FAIL
                )

    return True


# ---------------------------------------------------------------------------
# Database-Level Validation  (Spec §8.3)
# ---------------------------------------------------------------------------

def mfdb_validator_check_integrity(manifest_path: str) -> bool:
    """
    Strict integrity check for MFDB boot.
    Asserts that the record_count in the manifest matches the actual row count
    for every entity file. Raises MFDBValidationError on mismatch.
    """
    manifest_doc = _load_json(manifest_path)
    entries      = _rows_as_dicts(manifest_doc)
    
    for entry in entries:
        entity_name    = entry["entity_name"]
        file_path_rel  = entry["file_path"]
        declared_count = entry.get("record_count")
        
        if declared_count is None:
            continue
            
        resolved = _resolve_entity_path(manifest_path, file_path_rel)
        if not os.path.exists(resolved):
            continue # Already caught by validate_manifest
            
        entity_doc   = _load_json(resolved)
        actual_count = len(entity_doc.get("Values", []))
        
        if actual_count != declared_count:
            msg = f"Integrity Failure: Entity '{entity_name}' declares {declared_count} records, but found {actual_count}."
            _mstate.add_error(msg, f"Entity/{entity_name}/record_count")
            raise MFDBValidationError(msg, E_MFDB_BIDIRECTIONAL_FAIL) # Reuse appropriate code or add new
            
    return True

def mfdb_validator_validate_database(
    manifest_path: str,
    strict_fk: bool = False,
) -> bool:
    """
    Full MFDB database validation.

    Validates the manifest, then each entity file, then cross-database
    consistency (record_count, optional FK resolution).

    strict_fk=True enables advisory FK checks: any field ending in '_fk'
    with no matching primary_key declaration in the manifest raises a warning.

    Warnings never cause this function to return False; errors do.
    Returns True when all hard checks pass (warnings may exist).
    Raises MFDBValidationError on the first fatal error.
    """
    _mstate.reset()

    # Step 1: Validate the manifest itself.
    try:
        mfdb_validator_validate_manifest(manifest_path)
    except MFDBValidationError:
        raise  # state already populated

    manifest_doc = _load_json(manifest_path)
    entries      = _rows_as_dicts(manifest_doc)

    # Build PK map for FK advisory checks.
    pk_map = {
        e["entity_name"]: e.get("primary_key")
        for e in entries
        if e.get("primary_key")
    }

    # Step 2: Validate each entity file.
    for entry in entries:
        entity_name    = entry["entity_name"]
        file_path_rel  = entry["file_path"]
        declared_count = entry.get("record_count")

        resolved = _resolve_entity_path(manifest_path, file_path_rel)

        try:
            # Skip bidirectional check here — the manifest is the authority;
            # we do not want confusing errors if a file is moved and re-registered.
            mfdb_validator_validate_entity_file(resolved, check_bidirectional=True)
        except MFDBValidationError as exc:
            _mstate.add_error(
                f"Entity '{entity_name}' failed validation: {exc}",
                f"Entity/{entity_name}",
            )
            raise

        # record_count mismatch is informational (warning, not error).
        if declared_count is not None:
            entity_doc   = _load_json(resolved)
            actual_count = len(entity_doc.get("Values", []))
            if actual_count != declared_count:
                _mstate.add_warning(
                    f"Entity '{entity_name}': manifest declares record_count={declared_count}, "
                    f"actual={actual_count}. Call mfdb_core_sync_all_counts() to correct.",
                    f"Entity/{entity_name}/record_count",
                )

        # Step 3: FK advisory checks (strict mode only).
        if strict_fk:
            entity_doc = _load_json(resolved)
            fk_fields  = [
                f["name"]
                for f in entity_doc.get("Fields", [])
                if f["name"].endswith("_fk")
            ]
            for fk_field in fk_fields:
                target_found = any(
                    pk and (pk in fk_field or en.lower() in fk_field.lower())
                    for en, pk in pk_map.items()
                )
                if not target_found:
                    _mstate.add_warning(
                        f"Entity '{entity_name}': FK field '{fk_field}' has no matching "
                        f"primary_key declaration in the manifest. Consider adding a "
                        f"Relationships header (MFDB v1.1) for explicit FK mapping.",
                        f"Entity/{entity_name}/{fk_field}",
                    )

    return True


# ---------------------------------------------------------------------------
# Validation report
# ---------------------------------------------------------------------------

def mfdb_validator_get_report(manifest_path: str, strict_fk: bool = False) -> str:
    """
    Run full database validation and return a human-readable report string.
    Never raises — all outcomes (valid or invalid) are captured in the report.
    """
    valid = False
    try:
        valid = mfdb_validator_validate_database(manifest_path, strict_fk=strict_fk)
    except (MFDBValidationError, Exception):
        pass

    lines = [
        "=== MFDB Validation Report ===",
        f"Manifest : {manifest_path}",
        f"Status   : {'VALID' if valid else 'INVALID'}",
        "",
        f"Errors   : {len(_mstate.errors)}",
    ]
    if _mstate.has_errors():
        lines.append("---")
        lines.extend(_mstate.errors)

    lines += ["", f"Warnings : {len(_mstate.warnings)}"]
    if _mstate.has_warnings():
        lines.append("---")
        lines.extend(_mstate.warnings)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# State accessors (mirror lib_bejson_validator pattern)
# ---------------------------------------------------------------------------

def mfdb_validator_reset_state():                   _mstate.reset()
def mfdb_validator_has_errors()    -> bool:         return _mstate.has_errors()
def mfdb_validator_has_warnings()  -> bool:         return _mstate.has_warnings()
def mfdb_validator_get_errors()    -> list[str]:    return list(_mstate.errors)
def mfdb_validator_get_warnings()  -> list[str]:    return list(_mstate.warnings)
def mfdb_validator_error_count()   -> int:          return len(_mstate.errors)
def mfdb_validator_warning_count() -> int:          return len(_mstate.warnings)
