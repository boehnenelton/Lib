pub mod types;

use std::fs;
use std::io::{Write};
use std::path::{Path};
use chrono::Local;
use serde_json::{Value};
use types::*;

/// Load a BEJSON file from disk.
pub fn load_file<P: AsRef<Path>>(path: P) -> Result<BEJSONDocument> {
    let content = fs::read_to_string(path)
        .map_err(|e| BEJSONError::FieldNotFound(e.to_string()))?;
    let doc: BEJSONDocument = serde_json::from_str(&content)
        .map_err(|e| BEJSONError::InvalidOperation(format!("Parse error: {}", e)))?;
    Ok(doc)
}

/// Return the index of a field by name.
pub fn get_field_index(doc: &BEJSONDocument, field_name: &str) -> Result<usize> {
    doc.fields.iter().position(|f| f.name == field_name)
        .ok_or_else(|| BEJSONError::FieldNotFound(field_name.to_string()))
}

/// Strict 104db records-by-type lookup (index 0).
pub fn get_records_by_type<'a>(doc: &'a BEJSONDocument, record_type: &str) -> Result<Vec<&'a Vec<Value>>> {
    if doc.format_version != BEJSONVersion::V104db {
        return Err(BEJSONError::InvalidOperation("Operation requires 104db document".to_string()));
    }
    Ok(doc.values.iter()
        .filter(|row| row.first().and_then(|v| v.as_str()) == Some(record_type))
        .collect())
}

/// Strict field applicability check for 104db.
pub fn get_field_applicability(doc: &BEJSONDocument, field_name: &str) -> Result<String> {
    let idx = get_field_index(doc, field_name)?;
    let field = &doc.fields[idx];
    let rtp = &field.record_type_parent;

    if doc.format_version == BEJSONVersion::V104db {
        if rtp.is_none() {
            if field.extra.contains_key("applies_to") {
                return Err(BEJSONError::InvalidOperation(format!(
                    "Field '{}' uses legacy 'applies_to'. 104db requires 'Record_Type_Parent'.",
                    field_name
                )));
            }
            return Err(BEJSONError::InvalidOperation(format!(
                "Field '{}' missing Record_Type_Parent in 104db",
                field_name
            )));
        }
    }
    Ok(rtp.clone().unwrap_or_else(|| "common".to_string()))
}

/// Query records where field matches value.
pub fn query_records<'a>(doc: &'a BEJSONDocument, field_name: &str, search_value: &Value) -> Result<Vec<&'a Vec<Value>>> {
    let idx = get_field_index(doc, field_name)?;
    Ok(doc.values.iter()
        .filter(|row| row.get(idx) == Some(search_value))
        .collect())
}

/// Sort records by field.
pub fn sort_by_field(doc: &BEJSONDocument, field_name: &str, ascending: bool) -> Result<BEJSONDocument> {
    let idx = get_field_index(doc, field_name)?;
    let mut new_doc = doc.clone();
    new_doc.values.sort_by(|a, b| {
        let val_a = a.get(idx);
        let val_b = b.get(idx);
        let cmp = match (val_a, val_b) {
            (Some(v1), Some(v2)) => {
                // Handle nulls and different types
                if v1.is_null() && !v2.is_null() { std::cmp::Ordering::Greater }
                else if !v1.is_null() && v2.is_null() { std::cmp::Ordering::Less }
                else {
                    // Basic comparison for strings/numbers
                    if let (Some(s1), Some(s2)) = (v1.as_str(), v2.as_str()) {
                        s1.cmp(s2)
                    } else if let (Some(f1), Some(f2)) = (v1.as_f64(), v2.as_f64()) {
                        f1.partial_cmp(&f2).unwrap_or(std::cmp::Ordering::Equal)
                    } else {
                        v1.to_string().cmp(&v2.to_string())
                    }
                }
            },
            _ => std::cmp::Ordering::Equal,
        };
        if ascending { cmp } else { cmp.reverse() }
    });
    Ok(new_doc)
}

/// Atomic write with directory fsync parity.
pub fn atomic_write<P: AsRef<Path>>(path: P, doc: &BEJSONDocument, create_backup: bool) -> Result<()> {
    let path = path.as_ref();
    let target_dir = path.parent().ok_or_else(|| BEJSONError::WriteFailed("Invalid path".to_string()))?;
    
    if create_backup && path.exists() {
        let ts = Local::now().format("%Y%m%d_%H%M%S").to_string();
        let backup_path = target_dir.join(format!("{}.backup.{}", path.file_name().unwrap().to_str().unwrap(), ts));
        fs::copy(path, backup_path).map_err(|e| BEJSONError::BackupFailed(e.to_string()))?;
    }

    let json_text = serde_json::to_string_pretty(doc)
        .map_err(|e| BEJSONError::InvalidOperation(e.to_string()))?;

    // Create temp file as sibling
    let mut temp_file = tempfile::NamedTempFile::new_in(target_dir)
        .map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;
    
    temp_file.write_all(json_text.as_bytes()).map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;
    temp_file.flush().map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;
    temp_file.as_file().sync_all().map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;

    // Rename and fsync directory
    temp_file.persist(path).map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;
    
    // Sync parent directory
    let dir = fs::File::open(target_dir).map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;
    dir.sync_all().map_err(|e| BEJSONError::WriteFailed(e.to_string()))?;

    Ok(())
}

/// Coerce and validate a raw JSON value to the declared field type.
pub fn _coerce_value(value: &Value, field_type: &str) -> Result<Value> {
    match field_type {
        "string" => Ok(Value::String(value.to_string().replace("\"", ""))),
        "integer" | "number" => {
            if field_type == "integer" {
                if let Some(i) = value.as_i64() { return Ok(Value::Number(i.into())); }
                if let Ok(i) = value.to_string().replace("\"", "").parse::<i64>() { return Ok(Value::Number(i.into())); }
            } else {
                if let Some(f) = value.as_f64() { return Ok(Value::from(f)); }
                if let Ok(f) = value.to_string().replace("\"", "").parse::<f64>() { return Ok(Value::from(f)); }
            }
            Err(BEJSONError::TypeConversionFailed(format!("Cannot convert '{}' to {}", value, field_type)))
        },
        "boolean" => {
            if let Some(b) = value.as_bool() { return Ok(Value::Bool(b)); }
            let s = value.to_string().replace("\"", "").to_lowercase();
            if s == "true" { return Ok(Value::Bool(true)); }
            if s == "false" { return Ok(Value::Bool(false)); }
            Err(BEJSONError::TypeConversionFailed(format!("Cannot convert '{}' to boolean", value)))
        },
        _ => Ok(value.clone()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_coerce_value() {
        assert_eq!(_coerce_value(&Value::String("123".to_string()), "integer").unwrap(), Value::Number(123.into()));
        assert_eq!(_coerce_value(&Value::String("true".to_string()), "boolean").unwrap(), Value::Bool(true));
        assert!(_coerce_value(&Value::String("abc".to_string()), "integer").is_err());
    }
}
